package com.agent.platform.procurement.agent;

import com.agent.platform.runtime.*;
import java.util.Set;

public record AgentDefinition(String agentId, String instructions, String outputSchema,
                              ContextPolicy contextPolicy, Set<String> toolSet, AgentRunLimits runBudget) {
    public AgentDefinition { toolSet = Set.copyOf(toolSet); }
    public AgentExecutionProfile profile() {
        return new AgentExecutionProfile(agentId, instructions, toolSet, runBudget, false, contextPolicy);
    }
}
