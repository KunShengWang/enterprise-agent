package com.agent.platform.procurement.agent;

import com.agent.platform.procurement.erp.ProcurementErpAdapter;
import com.agent.platform.procurement.model.ProcurementCaseState;
import com.agent.platform.runtime.ToolExecutionRecord;
import com.agent.platform.runtime.ToolExecutionState;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import java.util.*;

/** Domain-owned blockers backed by canonical reads; supplier feasibility belongs to Sourcing. */
public final class RequisitionAssessment {
    private RequisitionAssessment() { }
    public static final Set<String> BLOCKERS=Set.of("ITEM_INACTIVE","REQUISITION_CLOSED","BUDGET_UNAVAILABLE","DUPLICATE_REQUEST");
    public static final Set<String> DEFERRED=Set.of("DELIVERY_FEASIBILITY","SUPPLIER_PERFORMANCE","SUPPLIER_PRICING");

    public static Map<String,Object> validate(JsonNode answer, ProcurementCaseState state,
                                              List<ToolExecutionRecord> reads,ObjectMapper json) {
        var blockers=enumArray(answer.path("blockingReasons"),BLOCKERS);
        var deferred=enumArray(answer.path("deferredChecks"),DEFERRED);
        if(!answer.path("subjectRequisitionId").isTextual() || !answer.path("departmentId").isTextual())
            throw new IllegalArgumentException("requisition subject and department required");
        String subject=answer.path("subjectRequisitionId").asText(), department=answer.path("departmentId").asText();
        if ("BLOCKED".equals(answer.path("status").asText()) != !blockers.isEmpty())
            throw new IllegalArgumentException("BLOCKED requires supported domain blockers");
        var items=new ArrayList<ProcurementErpAdapter.Item>();
        var budgets=new ArrayList<ProcurementErpAdapter.BudgetStatus>();
        var requisitions=new LinkedHashMap<String,ProcurementErpAdapter.Requisition>();
        var exactReads=new HashSet<String>();
        boolean requisitionsRead=false;
        for(var e:reads) {
            if(e.state()!=ToolExecutionState.SUCCEEDED || e.result()==null || !e.result().success())continue;
            String tool=e.toolName();
            if(!Set.of("mcp.erpnext.procurement_get_item","mcp.erpnext.procurement_get_budget_status",
                    "mcp.erpnext.procurement_get_requisition","mcp.erpnext.procurement_list_requisitions").contains(tool))continue;
            var data=json.readTree(e.result().content());
            if(tool.endsWith("get_item") && data.path("record").isObject())
                items.add(json.treeToValue(data.path("record"),ProcurementErpAdapter.Item.class));
            if(tool.endsWith("get_budget_status") && data.path("record").isObject())
                budgets.add(json.treeToValue(data.path("record"),ProcurementErpAdapter.BudgetStatus.class));
            if(tool.endsWith("get_requisition") && data.path("record").isObject()) {
                var r=json.treeToValue(data.path("record"),ProcurementErpAdapter.Requisition.class);requisitions.put(r.id(),r);
                exactReads.add(r.id());
            }
            if(tool.endsWith("list_requisitions")) {
                requisitionsRead=true;
                for(var node:data.path("records")) {
                    var r=json.treeToValue(node,ProcurementErpAdapter.Requisition.class);requisitions.put(r.id(),r);
                }
            }
        }
        var targetItems=items.stream().filter(i->state==null || Objects.equals(i.id(),state.productDescription())).toList();
        if(!subject.isBlank() && (!exactReads.contains(subject) || !department.equals(requisitions.get(subject).departmentId())))
            throw new IllegalArgumentException("subject requires exact canonical requisition read");
        var matching=requisitions.values().stream().filter(r->state!=null
                && Objects.equals(r.itemId(),state.productDescription()) && Objects.equals(r.quantity(),state.quantity())
                && department.equals(r.departmentId()) && !subject.equals(r.id())
                && !Set.of("Cancelled","Stopped").contains(r.status())).toList();
        // Similar SKU alone is advisory. A confirmed duplicate must match the current quantity and department.
        boolean duplicate=!department.isBlank() && !matching.isEmpty();
        boolean inactive=targetItems.stream().anyMatch(i->!i.active());
        var targetBudgets=budgets.stream().filter(b->department.equals(b.departmentId())).toList();
        boolean budgetUnavailable=targetBudgets.stream().anyMatch(b->b.available().signum()<=0);
        boolean closed=!subject.isBlank() && Set.of("Cancelled","Stopped").contains(requisitions.get(subject).status());
        Map<String,Boolean> supported=Map.of("ITEM_INACTIVE",inactive,"BUDGET_UNAVAILABLE",budgetUnavailable,
                "REQUISITION_CLOSED",closed,"DUPLICATE_REQUEST",duplicate);
        for(String code:blockers)if(!supported.get(code))throw new IllegalArgumentException("unsupported requisition blocker: "+code);
        if("READY".equals(answer.path("status").asText()) && (inactive || budgetUnavailable || closed))
            throw new IllegalArgumentException("READY contradicts canonical domain facts");
        var result=new LinkedHashMap<String,Object>();
        result.put("blockingReasons",blockers);result.put("deferredChecks",deferred);
        result.put("subjectRequisitionId",subject);result.put("departmentId",department);
        result.put("caseComplete",state!=null && state.missingFields().isEmpty());
        result.put("itemStatus",targetItems.isEmpty()?"UNKNOWN":inactive?"INACTIVE":"ACTIVE");
        result.put("budgetStatus",targetBudgets.isEmpty()?"UNKNOWN":budgetUnavailable?"UNAVAILABLE":"AVAILABLE_CEILING_OBSERVED");
        result.put("duplicateStatus",duplicate?"MATCHING_REQUESTS_OBSERVED":requisitionsRead?"NO_EXACT_MATCH_OBSERVED":"NOT_CHECKED");
        return result;
    }
    private static Set<String> enumArray(JsonNode node,Set<String> allowed) {
        if(!node.isArray() || node.size()>allowed.size())throw new IllegalArgumentException("domain enum array required");
        var values=new LinkedHashSet<String>();
        for(var value:node)if(!value.isTextual() || !allowed.contains(value.asText()) || !values.add(value.asText()))
            throw new IllegalArgumentException("invalid domain responsibility");
        return values;
    }
}
