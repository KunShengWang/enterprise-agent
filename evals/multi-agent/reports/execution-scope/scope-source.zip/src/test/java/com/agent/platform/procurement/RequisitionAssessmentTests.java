package com.agent.platform.procurement;

import com.agent.platform.procurement.agent.RequisitionAssessment;
import com.agent.platform.procurement.erp.ProcurementErpAdapter.*;
import com.agent.platform.procurement.model.ProcurementCaseState;
import com.agent.platform.runtime.*;
import com.agent.platform.tool.*;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.JsonNode;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class RequisitionAssessmentTests {
    final ObjectMapper json=new ObjectMapper();
    final ProcurementCaseState state=new ProcurementCaseState("workstation","item-1",20,new BigDecimal("300000"),"CNY",21,
            Map.of("gpuMemoryMinGb","24"),Map.of("deliveryPriority","HIGH"),Set.of(),List.of(),"SOURCING");
    Source source(String id){return new Source("erpnext","canonical",id,Instant.EPOCH,Instant.EPOCH);}
    Requisition req(String id,int qty){return new Requisition(id,"department-1","item-1",qty,LocalDate.of(2026,12,15),"Draft",source(id));}
    ToolExecutionRecord read(String tool,Object data){
        String id=UUID.randomUUID().toString();var r=new ToolCallRequest("mcp.erpnext.procurement_"+tool,id,Map.of());
        return ToolExecutionRecord.running("child",r).withResult(ToolExecutionState.SUCCEEDED,
                new ToolCallResult(r.toolName(),true,json.writeValueAsString(data),"",Map.of()),"");
    }
    JsonNode answer(String status,List<String> blockers,List<String> deferred,String subject){
        return json.valueToTree(Map.of("status",status,"blockingReasons",blockers,"deferredChecks",deferred,
                "subjectRequisitionId",subject,"departmentId","department-1"));
    }
    List<ToolExecutionRecord> reads(int otherQty){return List.of(
            read("get_requisition",Map.of("record",req("request-1",20))),
            read("list_requisitions",Map.of("records",List.of(req("request-1",20),req("request-2",otherQty)))));}
    @Test void differentQuantityAndSelfAreNotConfirmedDuplicate(){
        assertThrows(IllegalArgumentException.class,()->RequisitionAssessment.validate(
                answer("BLOCKED",List.of("DUPLICATE_REQUEST"),List.of(),"request-1"),state,reads(8),json));
        var result=RequisitionAssessment.validate(answer("READY",List.of(),List.of("DELIVERY_FEASIBILITY","SUPPLIER_PERFORMANCE"),"request-1"),state,reads(8),json);
        assertEquals("NO_EXACT_MATCH_OBSERVED",result.get("duplicateStatus"));
        assertEquals(Set.of(),result.get("blockingReasons"));
    }
    @Test void sameDepartmentItemAndQuantitySupportDuplicateBlock(){
        var result=RequisitionAssessment.validate(answer("BLOCKED",List.of("DUPLICATE_REQUEST"),List.of(),"request-1"),state,reads(20),json);
        assertEquals("MATCHING_REQUESTS_OBSERVED",result.get("duplicateStatus"));
        // A new requirement is distinct from an existing ERP request and may match even one record.
        result=RequisitionAssessment.validate(answer("BLOCKED",List.of("DUPLICATE_REQUEST"),List.of(),""),state,
                List.of(read("list_requisitions",Map.of("records",List.of(req("request-1",20))))),json);
        assertEquals("MATCHING_REQUESTS_OBSERVED",result.get("duplicateStatus"));
    }
    @Test void supplierUnknownsCannotBeRequisitionBlockers(){
        assertThrows(IllegalArgumentException.class,()->RequisitionAssessment.validate(
                answer("BLOCKED",List.of("DELIVERY_FEASIBILITY"),List.of(),"request-1"),state,reads(8),json));
        assertThrows(IllegalArgumentException.class,()->RequisitionAssessment.validate(
                answer("BLOCKED",List.of(),List.of("DELIVERY_FEASIBILITY"),"request-1"),state,reads(8),json));
    }
    @Test void inactiveItemAndUnavailableBudgetRemainRealBlockers(){
        var records=List.of(read("get_item",Map.of("record",new Item("item-1","name","workstation","Nos",24,"36",source("item-1"),false))),
                read("get_budget_status",Map.of("record",new BudgetStatus("b1","department-1",BigDecimal.ZERO,BigDecimal.ZERO,BigDecimal.ZERO,"CNY","2026",source("b1")))));
        var result=RequisitionAssessment.validate(answer("BLOCKED",List.of("ITEM_INACTIVE","BUDGET_UNAVAILABLE"),List.of(),""),state,records,json);
        assertEquals("INACTIVE",result.get("itemStatus"));assertEquals("UNAVAILABLE",result.get("budgetStatus"));
        assertThrows(IllegalArgumentException.class,()->RequisitionAssessment.validate(answer("READY",List.of(),List.of(),""),state,records,json));
    }
    @Test void unboundSubjectAndMissingDomainContractAreRejected(){
        assertThrows(IllegalArgumentException.class,()->RequisitionAssessment.validate(answer("READY",List.of(),List.of(),"invented"),state,reads(8),json));
        assertThrows(IllegalArgumentException.class,()->RequisitionAssessment.validate(json.valueToTree(Map.of("status","BLOCKED")),state,reads(8),json));
    }
    @Test void sameQuantityInDifferentDepartmentOrClosedRequestIsNotDuplicate(){
        for(var other:List.of(new Requisition("other","department-2","item-1",20,LocalDate.of(2026,12,15),"Draft",source("other")),
                new Requisition("other","department-1","item-1",20,LocalDate.of(2026,12,15),"Cancelled",source("other")))) {
            var records=List.of(read("get_requisition",Map.of("record",req("request-1",20))),
                    read("list_requisitions",Map.of("records",List.of(req("request-1",20),other))));
            assertThrows(IllegalArgumentException.class,()->RequisitionAssessment.validate(
                    answer("BLOCKED",List.of("DUPLICATE_REQUEST"),List.of(),"request-1"),state,records,json));
            assertEquals("NO_EXACT_MATCH_OBSERVED",RequisitionAssessment.validate(
                    answer("READY",List.of(),List.of("DELIVERY_FEASIBILITY","SUPPLIER_PERFORMANCE","SUPPLIER_PRICING"),"request-1"),state,records,json).get("duplicateStatus"));
        }
    }
    @Test void closedSubjectCannotBeMadeReadyByModelAssertion(){
        var closed=new Requisition("request-1","department-1","item-1",20,LocalDate.of(2026,12,15),"Stopped",source("request-1"));
        var records=List.of(read("get_requisition",Map.of("record",closed)));
        assertEquals(Set.of("REQUISITION_CLOSED"),RequisitionAssessment.validate(
                answer("BLOCKED",List.of("REQUISITION_CLOSED"),List.of(),"request-1"),state,records,json).get("blockingReasons"));
        assertThrows(IllegalArgumentException.class,()->RequisitionAssessment.validate(
                answer("READY",List.of(),List.of(),"request-1"),state,records,json));
    }
}
