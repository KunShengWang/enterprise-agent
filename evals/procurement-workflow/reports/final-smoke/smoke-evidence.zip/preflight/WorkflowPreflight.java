import com.agent.platform.EnterpriseAgentApplication;
import com.agent.platform.config.*;
import com.agent.platform.runtime.*;
import com.agent.platform.procurement.workflow.*;
import com.agent.platform.procurement.erp.*;
import com.agent.platform.procurement.tool.*;
import com.agent.platform.mcp.*;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import tools.jackson.databind.ObjectMapper;
import java.nio.file.*;
import java.util.*;
public class WorkflowPreflight {
 public static void main(String[] args)throws Exception{
  try(var context=new SpringApplicationBuilder(EnterpriseAgentApplication.class).profiles("erpnext").web(WebApplicationType.NONE)
   .properties("spring.main.lazy-initialization=true","enterprise-agent.mock-mode=false","enterprise-agent.model-tool-calling-mode=native","enterprise-agent.workbench.web.enabled=false").run()){
   var json=context.getBean(ObjectMapper.class);var props=context.getBean(AgentProperties.class);
   var profiles=new ProcurementStageProfiles(props,json);var model=context.getBean(AgentModelGateway.class);
   if(!(model instanceof NativeToolCallingAgentModelGateway))throw new IllegalStateException("native model required");
   var options=(org.springframework.ai.deepseek.DeepSeekChatOptions)org.springframework.test.util.ReflectionTestUtils.getField(model,"configuredOptions");
   var server=new McpProperties.Server();server.setServerName("erpnext");server.setToolNamePrefix("mcp.erpnext.");
   server.setCommand(Path.of(System.getProperty("java.home"),"bin","java.exe").toString());
   server.setArgs(List.of("-cp",System.getProperty("java.class.path"),ProcurementMcpServer.class.getName()));
   var config=new McpProperties();config.setServers(List.of(server));var gateway=new StdioMcpToolGateway(config,json);
   try{
    var tools=new ArrayList<com.agent.platform.tool.ToolDefinition>(gateway.discoverTools());tools.addAll(new ProcurementToolCatalog().definitions());
    var result=new LinkedHashMap<String,Object>();
    result.put("stageProfiles",Arrays.stream(ProcurementStage.values()).map(profiles::get).toList());
    result.put("agentProperties",json.valueToTree(props));
    result.put("effectiveModelOptions",Map.of("model",options.getModel(),"temperature",options.getTemperature(),"maxTokens",options.getMaxTokens()));
    var scoped=new LinkedHashMap<String,Object>();
    for(var stage:ProcurementStage.values())scoped.put(stage.name(),tools.stream().filter(t->profiles.get(stage).toolScope().contains(t.name())).toList());
    result.put("toolsByStage",scoped);
    Files.writeString(Path.of(args[0]),json.writeValueAsString(result));
   }finally{gateway.shutdown();}
  }
 }
}
