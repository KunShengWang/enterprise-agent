"""Offline workflow checks, additive to the frozen V2.2 business grader."""
import json
import collections
import jsonschema


def acceptance(raw):
    runs=raw.get('stageRuns',[])
    profiles={p['stage']:p for p in raw['controls'].get('stageProfiles',[])}
    checks={}
    stages=[r['request']['metadata'].get('procurementStage') for r in runs]
    checks['legal_stage_sequence']=bool(stages) and stages==['REQUISITION','SOURCING','RFQ'][:len(stages)]
    checks['single_identity']=bool(runs) and all(r['executionProfile']['name']=='PROCUREMENT' and r['request']['metadata'].get('agentId')=='PROCUREMENT' for r in runs)
    if not checks['legal_stage_sequence']:
        return dict(passed=False,checks=checks,failures=['legal_stage_sequence'])
    checks['one_workflow']=bool(runs) and len({r['request']['metadata'].get('workflowId') for r in runs})==1
    schema_ok=True;version_ok=True;scope_ok=True;context_ok=True
    for r in runs:
        metadata=r['request']['metadata'];stage=metadata['procurementStage'];p=profiles[stage]
        try:
            jsonschema.validate(metadata.get('validatedStageOutput'),json.loads(p['outputSchema']))
        except (jsonschema.ValidationError,TypeError): schema_ok=False
        packet=json.loads(r['request']['question']);case=packet.get('canonicalCase') or {}
        version_ok &= metadata['workflowCaseVersion']==case.get('version',-1) and metadata['workflowCaseId']==case.get('caseId','')
        if stage=='SOURCING':
            version_ok &= case.get('status')=='SOURCING' and not packet['validatedPriorStage'].get('validatedBlockers') and packet['validatedPriorStage'].get('authority')=='java-validated-domain-result'
        if stage=='RFQ':
            bound=[e for e in raw['executions'] if e['toolCallId']==metadata.get('workflowFinalizeRef') and e['state']=='SUCCEEDED' and e['toolName']=='procurement_recommendation_finalize']
            version_ok &= case.get('status')=='RECOMMENDATION_READY' and len(bound)==1
            if bound:
                final=json.loads(bound[0]['result']['content']);version_ok &= final['caseId']==case['caseId'] and final['caseVersion']==case['version']
        schemas=set()
        for m in raw.get('models',[]):
            q=m['request']
            if q['runId']!=r['runId']:continue
            names={t['name'] for t in q['tools']};scope_ok &= names==set(p['toolScope'])
            schemas.add(m['schemaSha256'])
            context_ok &= all(msg['runId']==r['runId'] or msg['type']=='CANONICAL_CONTEXT' for msg in q['messages'])
        scope_ok &= len(schemas)==1
        # Packets carry structured canonical state, never assistant/tool message envelopes.
        context_ok &= set(packet)=={'userInput','canonicalCase','validatedPriorStage','departmentId','stage'}
    checks.update(stage_output_schema_valid=schema_ok,canonical_state_consistent=version_ok,fixed_tool_scope=scope_ok,no_cross_stage_raw_context=context_ok)
    checks['workflow_not_failed']=raw['result']['state'] not in ('FAILED','MANUAL_REVIEW','RUNNING','CREATED')
    return dict(passed=all(checks.values()),checks=checks,failures=[k for k,v in checks.items() if not v])


def metrics(raw):
    result={};models=raw.get('models',[])
    for r in raw.get('stageRuns',[]):
        stage=r['request']['metadata']['procurementStage'];m=[x for x in models if x['request']['runId']==r['runId']]
        usages=[x.get('turn',{}).get('usage') for x in m]
        known=bool(usages) and all(u and u.get('totalTokens',0)>0 for u in usages)
        packet=json.loads(r['request']['question']);carried=json.dumps({k:packet[k] for k in ('canonicalCase','validatedPriorStage')},ensure_ascii=False)
        result[stage]=dict(run_id=r['runId'],model_calls=len(m),input_tokens=sum(u['promptTokens'] for u in usages) if known else None,
            output_tokens=sum(u['completionTokens'] for u in usages) if known else None,total_tokens=sum(u['totalTokens'] for u in usages) if known else None,
            peak_context_tokens=max(u['promptTokens'] for u in usages) if known else None,
            tool_calls=sum(len(x.get('turn',{}).get('toolCalls',[])) for x in m),
            model_latency_ms=sum(x['latencyMs'] for x in m),carried_context_estimated_tokens=sum(1 if ord(c)>127 else .25 for c in carried),
            state=r['state'],stop_reason=r.get('runtimeState',{}).get('stopReason'),budget=r['budgetSnapshot'])
    return dict(stages=result,stage_runs=len(result),model_turns=len(models),tool_calls=sum(s['tool_calls'] for s in result.values()),
        overall_max_context=max((s['peak_context_tokens'] or 0 for s in result.values()),default=0),
        clarification_pauses=int('NEEDS_USER_INPUT' in raw['result'].get('answer','')),workflow_errors=int(raw['result']['state']=='FAILED'),
        task_latency_ms=raw.get('taskLatencyMs'),stage_token_scope='Agent model calls only; guardrail usage is included in frozen total provider metrics',
        carried_token_scope='local estimate, not provider billing')
