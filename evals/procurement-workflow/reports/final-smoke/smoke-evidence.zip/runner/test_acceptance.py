import copy
import unittest
from acceptance import acceptance

class WorkflowAcceptanceTests(unittest.TestCase):
    def fixture(self):
        import json
        packet=dict(userInput='x',canonicalCase={},validatedPriorStage={},departmentId='d',stage='REQUISITION')
        return dict(controls=dict(stageProfiles=[dict(stage='REQUISITION',outputSchema=json.dumps(dict(type='object',additionalProperties=False,properties={})),toolScope=[])]),
            stageRuns=[dict(runId='r',executionProfile=dict(name='PROCUREMENT'),request=dict(question=json.dumps(packet),metadata=dict(procurementStage='REQUISITION',agentId='PROCUREMENT',workflowId='w',workflowCaseVersion=-1,workflowCaseId='',validatedStageOutput={})))],
            models=[dict(schemaSha256='fixed',request=dict(runId='r',tools=[],messages=[dict(runId='r',type='USER')]))],result=dict(state='COMPLETED'))
    def test_valid(self):self.assertTrue(acceptance(self.fixture())['passed'])
    def test_illegal_skip(self):
        r=self.fixture();r['stageRuns'][0]['request']['metadata']['procurementStage']='RFQ';self.assertFalse(acceptance(r)['passed'])
    def test_wrong_identity(self):
        r=self.fixture();r['stageRuns'][0]['executionProfile']['name']='SUPERVISOR';self.assertFalse(acceptance(r)['passed'])
    def test_leaked_history(self):
        r=self.fixture();r['models'][0]['request']['messages'][0]['runId']='prior';self.assertFalse(acceptance(r)['passed'])
    def test_changing_tools(self):
        r=self.fixture();m=copy.deepcopy(r['models'][0]);m['schemaSha256']='changed';r['models'].append(m);self.assertFalse(acceptance(r)['passed'])
    def test_forged_version(self):
        r=self.fixture();r['stageRuns'][0]['request']['metadata']['workflowCaseVersion']=4;self.assertFalse(acceptance(r)['passed'])
    def test_invalid_schema(self):
        r=self.fixture();r['stageRuns'][0]['request']['metadata']['validatedStageOutput']={'unknown':1};self.assertFalse(acceptance(r)['passed'])
    def test_failed_run(self):
        r=self.fixture();r['result']['state']='FAILED';self.assertFalse(acceptance(r)['passed'])
    def test_missing_output(self):
        r=self.fixture();del r['stageRuns'][0]['request']['metadata']['validatedStageOutput'];self.assertFalse(acceptance(r)['passed'])

if __name__=='__main__':unittest.main()
