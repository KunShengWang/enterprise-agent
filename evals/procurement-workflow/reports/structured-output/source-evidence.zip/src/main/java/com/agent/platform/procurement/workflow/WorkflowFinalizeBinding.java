package com.agent.platform.procurement.workflow;

import com.agent.platform.runtime.*;
import com.agent.platform.procurement.tool.ProcurementToolCatalog;
import org.springframework.stereotype.Component;
import java.util.*;

/** Cross-stage reference accepted only from server-created PROCUREMENT run records. */
@Component
public final class WorkflowFinalizeBinding {
    private final AgentRunStore runs;private final ToolExecutionStore tools;
    public WorkflowFinalizeBinding(AgentRunStore runs,ToolExecutionStore tools){this.runs=runs;this.tools=tools;}
    public Optional<ToolExecutionRecord> find(String runId){
        var target=runs.find(runId).orElse(null);
        if(target==null || target.executionProfile()==null || !"PROCUREMENT".equals(target.executionProfile().name())
                || !"RFQ".equals(target.request().metadata().get("procurementStage")))return Optional.empty();
        String ref=Objects.toString(target.request().metadata().get("workflowFinalizeRef"),"");
        var receipt=tools.findToolExecution(ref).orElseThrow(()->new IllegalArgumentException("missing workflow Finalize"));
        var source=runs.find(receipt.runId()).orElseThrow();
        if(!"PROCUREMENT".equals(source.executionProfile().name()) || !"SOURCING".equals(source.request().metadata().get("procurementStage"))
                || !source.conversationId().equals(target.conversationId()) || !source.userId().equals(target.userId())
                || !Objects.equals(source.request().metadata().get("tenantId"),target.request().metadata().get("tenantId"))
                || !Objects.equals(source.request().metadata().get("workflowId"),target.request().metadata().get("workflowId"))
                || receipt.state()!=ToolExecutionState.SUCCEEDED || receipt.result()==null || !receipt.result().success()
                || !ProcurementToolCatalog.RECOMMENDATION_FINALIZE.equals(receipt.toolName()))throw new IllegalArgumentException("invalid workflow Finalize binding");
        return Optional.of(receipt);
    }
    public boolean permits(String runId,String ref){return find(runId).map(r->r.toolCallId().equals(ref)).orElse(false);}
}
