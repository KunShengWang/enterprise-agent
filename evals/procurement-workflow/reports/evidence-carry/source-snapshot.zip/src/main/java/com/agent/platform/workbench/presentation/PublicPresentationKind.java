package com.agent.platform.workbench.presentation;

public enum PublicPresentationKind {
    TASK_UNDERSTANDING,
    ROUTE_SUMMARY,
    STANDARD_PROCESS,
    EXECUTION_PLAN,
    ACTION_STARTED,
    ACTION_COMPLETED,
    TOOL_ACTIVITY,
    AGENT_DELEGATION,
    WAITING_FOR_USER,
    CONFIRMATION_REQUIRED,
    APPROVAL_REQUIRED,
    RETRY,
    RECOVERY,
    FINAL_RESULT,
    ERROR
}
