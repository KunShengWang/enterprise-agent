import json, shutil, xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
HERE=ROOT/'target/delivery-20261007'
BASE=ROOT.parent/'enterprise-agent-reliability-v1-diagnostic'
def collect(root,suffix):
    files=list((root/'target/surefire-reports').glob('TEST-*'+suffix+'*.xml'))
    assert files,suffix
    summary=dict(tests=0,failures=0,errors=0,skip=0)
    skips=[]
    for p in files:
        suite=ET.parse(p).getroot()
        for key,attr in [('tests','tests'),('failures','failures'),('errors','errors'),('skip','skipped')]:
            summary[key]+=int(suite.attrib[attr])
        for case in suite.findall('testcase'):
            if case.find('skipped') is not None:
                skips.append(dict(classname=case.attrib.get('classname'),name=case.attrib['name'],
                                 reason=case.find('skipped').attrib.get('message')))
    summary['pass']=summary['tests']-summary['skip']-summary['errors']-summary['failures']
    summary['skips']=skips
    return summary
legacy=sorted((ROOT/'target/procurement-v0').glob('*/results.json'),key=lambda p:p.stat().st_mtime)[-1]
initial=json.loads(legacy.read_text())
same={}
for relative in ['src/main/java/com/agent/platform/mcp/StdioMcpToolGateway.java',
                 'src/test/java/com/agent/platform/mcp/StdioMcpToolGatewayTests.java',
                 'src/test/java/com/agent/platform/mcp/FakeMcpServerApplication.java','pom.xml']:
    same[relative]=(ROOT/relative).read_bytes()==(BASE/relative).read_bytes()
assert all(same.values()),same
result=dict(focused=collect(ROOT,'delivery-20261007-focused'),initial_legacy=initial,
            controlled_mcp_baseline=collect(BASE,'delivery-20261007-mcp-baseline'),
            controlled_mcp_patch=collect(ROOT,'delivery-20261007-mcp-patch'),
            mcp_dependencies_byte_identical=same,
            test_environment_override='JDK_JAVA_OPTIONS=-XX:TieredStopAtLevel=1; process-local and restored; timeout/source/assertions unchanged',
            new_model_trials=0,postgres_it='NOT RUN; no isolated environment',
            initial_failure_preserved=True)
assert result['focused']['failures']==result['focused']['errors']==0
assert result['controlled_mcp_baseline']['errors']>0,'Baseline should reproduce MCP issue'
full=next(r for r in initial if r['phase']=='full')
failed_suites=[s for s in full['suites'] if s['errors'] or s['failures']]
assert len(failed_suites)==1 and failed_suites[0]['name'].startswith('com.agent.platform.mcp.StdioMcpToolGatewayTests')
assert all(r['exitCode']==r['failures']==r['errors']==0 for r in initial if r['phase']!='full')
result['final_gate']='FULL_SUITE_FAILED_EXISTING_MCP_BASELINE_FAILURE'
result['scoped_checks']='PASS; focused, procurement, replay and build'
result['full_suite_not_passed']=True
(HERE/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(BASE/'target/delivery-20261007/mcp-baseline.log',HERE/'mcp-baseline.log')
for p in (BASE/'target/surefire-reports').glob('*delivery-20261007-mcp-baseline*'):
    shutil.copyfile(p,HERE/p.name)
print(json.dumps({k: {a:result[k][a] for a in ('tests','pass','failures','errors','skip')} for k in ('focused','controlled_mcp_baseline','controlled_mcp_patch')}))
