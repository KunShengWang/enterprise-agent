import gzip, hashlib, io, json, os, re, subprocess, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MAIN = ROOT.parent / 'enterprise-agent'
OUT = ROOT / 'evals/context-reliability/reports/delivery-20261007'
HERE = ROOT / 'target/delivery-20261007'
sha = lambda b: hashlib.sha256(b).hexdigest()
def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root).decode('utf-8').strip()
def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def normalized_manifest(root):
    files = sorted([*root.glob('src/main/**/*.java'), *root.glob('src/main/resources/**/*.yaml')])
    return {p.relative_to(root).as_posix():sha(p.read_bytes().replace(b'\r\n', b'\n')) for p in files}
def protected():
    paths = [MAIN/'src/main/java/com/agent/platform/procurement/tool/ProcurementToolHandler.java']
    fixtures = json.loads((ROOT/'evals/regression/legacy-v1/fixtures.json').read_text())['files']
    paths += [root / row['path'] for root in (MAIN,ROOT) for row in fixtures]
    holdout = ROOT.parent/'enterprise-agent-reliability-v1-clean/target/harness-reliability/holdout-20261005-r1'
    paths += [p for p in holdout.rglob('*') if p.is_file()]
    historical = ROOT/'target/context-reliability'
    paths += [p for p in historical.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    paths += [p for p in (MAIN/'evals/harness-reliability/reports/acceptance-20261005').rglob('*') if p.is_file()]
    return dict(hashes={str(p):sha(p.read_bytes()) for p in paths},tags=git(MAIN,'show-ref','--tags'))
def verify_protected():
    before = json.loads((HERE/'protected-start.json').read_text(encoding='utf-8'))
    assert all(Path(p).is_file() and sha(Path(p).read_bytes())==v for p,v in before['hashes'].items()), 'Protected bytes changed'
    assert git(MAIN,'show-ref','--tags')==before['tags'], 'Existing tags changed'
    return len(before['hashes'])
def members(label, data):
    if data.startswith(b'PK\x03\x04'):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            assert z.testzip() is None, label
            for name in z.namelist():
                if not name.endswith('/'):
                    yield from members(label+'!'+name,z.read(name))
    elif data.startswith(b'\x1f\x8b'):
        yield from members(label+'!gunzip',gzip.decompress(data))
    else:
        yield label,data
def secrets():
    found=set()
    for root in (ROOT,MAIN):
        p=root/'infra/erpnext/.env'
        if p.exists():
            for line in p.read_text(encoding='utf-8').splitlines():
                key,sep,value=line.partition('=')
                if sep and re.search(r'(PASSWORD|SECRET|API_KEY|TOKEN)',key,re.I):
                    value=value.strip().strip('\"\'')
                    if len(value)>=8: found.add(value.encode())
    for key,value in os.environ.items():
        if re.search(r'(PASSWORD|SECRET|API_KEY|TOKEN)',key,re.I) and len(value)>=12:
            found.add(value.encode())
    return found
def scan(files):
    known=secrets(); candidates=[]; count=0
    patterns=[rb'(?m)^-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n[A-Za-z0-9+/=]{32,}',
              rb'\b(?:sk-[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16})\b',
              rb'(?i)authorization[\"\s:=]+bearer\s+[A-Za-z0-9._-]{20,}']
    for label,data in files:
        for name,content in members(label,data):
            count+=1
            if any(secret in content for secret in known): candidates.append(dict(path=name,kind='known-local-secret'))
            if any(re.search(pattern,content) for pattern in patterns): candidates.append(dict(path=name,kind='credential-pattern'))
    return dict(entries=count,credential_candidates=candidates,zip_integrity_pass=True)

action=sys.argv[1]
if action=='snapshot':
    write(HERE/'protected-start.json',protected())
    write(HERE/'production-start.json',normalized_manifest(ROOT))
    print('Protected snapshot saved')
elif action=='audit':
    accept=MAIN/'evals/harness-reliability/reports/acceptance-20261005'
    checks=json.loads((accept/'checksums.json').read_text())
    assert all(sha((accept/p).read_bytes())==v for p,v in checks.items()), 'Acceptance checksum mismatch'
    files=[(str(p),p.read_bytes()) for p in accept.iterdir() if p.is_file()]
    historical=ROOT/'target/context-reliability'
    files += [(str(p),p.read_bytes()) for p in historical.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    result=scan(files);write(HERE/'archive-preflight-scan.json',result)
    print(json.dumps(result))
    assert not result['credential_candidates'], 'Credential scan blocked archive'
elif action=='archive':
    count=verify_protected()
    OUT.mkdir(parents=True,exist_ok=True)
    selection=[]
    history=ROOT/'target/context-reliability'
    for p in history.rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts: selection.append(('historical/'+p.relative_to(history).as_posix(),p))
    for p in HERE.glob('*'):
        if p.is_file():
            selection.append(('delivery/'+p.name,p))
    legacy=sorted((ROOT/'target/procurement-v0').glob('*/results.json'), key=lambda p:p.stat().st_mtime)[-1].parent
    for p in legacy.rglob('*'):
        if p.is_file(): selection.append(('delivery/legacy/'+p.relative_to(legacy).as_posix(),p))
    reports=ROOT/'target/surefire-reports'
    for p in reports.glob('*delivery-20261007-focused*'):
        if p.is_file(): selection.append(('delivery/surefire/'+p.name,p))
    results=json.loads((legacy/'results.json').read_text())
    assert isinstance(results,list) and {r['phase'] for r in results}=={'procurement','replay','full','build'}
    assert all(r['exitCode']==r['failures']==r['errors']==0 for r in results if r['phase']!='full')
    validation=json.loads((HERE/'validation.json').read_text())
    assert validation['scoped_checks']=='PASS; focused, procurement, replay and build'
    assert validation['full_suite_not_passed'] is True
    for p in reports.glob('*'+legacy.name+'*'):
        if p.is_file(): selection.append(('delivery/surefire/'+p.name,p))
    for p in reports.glob('*delivery-20261007-mcp-patch*'):
        if p.is_file(): selection.append(('delivery/surefire/'+p.name,p))
    files=[(name,p.read_bytes()) for name,p in selection]
    checked=scan(files);assert not checked['credential_candidates'],checked
    with zipfile.ZipFile(OUT/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in files:z.writestr(name,data)
    index={name:dict(sha256=sha(data),bytes=len(data)) for name,data in files}
    write(OUT/'archive-manifest.json',index)
    write(OUT/'evidence-scan.json',checked)
    for source,name in [(history/'rob04-regression-20261006-r1/result.json','historical-rob04-result.json'),
                        (history/'rob04-regression-20261006-r1/preservation-verification.json','historical-preservation.json'),
                        (history/'mcp-ab-20261006/full-results.json','historical-full-results.json'),
                        (legacy/'results.json','initial-legacy-results.json'),
                        (HERE/'validation.json','delivery-validation.json')]:
        (OUT/name).write_bytes(source.read_bytes())
    production=normalized_manifest(ROOT)
    expected=json.loads((HERE/'production-start.json').read_text())
    assert production==expected,'Production source changed while testing'
    write(OUT/'source-provenance.json',dict(baseline=git(ROOT,'rev-parse','HEAD'),
          production=production,protected_file_count=count,
          historical_model_evidence='2026-10-06 exposed ROB-04, before 2026-10-07 two defensive guards',
          current_model_trials=0,original_holdout='11/12; never relabel as 12/12',
          handler_included=False,existing_tags_unchanged=True))
    write(OUT/'checksums.json',{p.name:sha(p.read_bytes()) for p in OUT.iterdir() if p.is_file() and p.name!='checksums.json'})
    print(json.dumps(dict(archive_bytes=(OUT/'evidence.zip').stat().st_size,entries=len(files),protected=count)))
elif action=='verify':
    count=verify_protected()
    checks=json.loads((OUT/'checksums.json').read_text())
    assert all(sha((OUT/p).read_bytes())==v for p,v in checks.items())
    current=normalized_manifest(MAIN);expected=json.loads((OUT/'source-provenance.json').read_text())['production']
    differences=[p for p in set(current)|set(expected) if current.get(p)!=expected.get(p)]
    assert differences==['src/main/java/com/agent/platform/procurement/tool/ProcurementToolHandler.java'],differences
    print(json.dumps(dict(protected=count,archive_checksums='PASS',integrated_production='MATCH except preserved Handler comments')))
