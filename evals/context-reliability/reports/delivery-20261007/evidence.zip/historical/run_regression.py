from pathlib import Path
import importlib.util,os,json,subprocess,sys,hashlib
ROOT=Path.cwd();HERE=ROOT/'target/context-reliability';BASE=HERE/'rob04-regression-20261006-r1'
spec=importlib.util.spec_from_file_location('frozen_harness',ROOT/'evals/harness-core/run.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);l=h.legacy
TASK=ROOT/'evals/procurement-v2/tasks/robustness/ROB-04.json'
def normalized(v,key=''):
    if isinstance(v,dict):return {k:normalized(x,k) for k,x in v.items()}
    if isinstance(v,list):
        x=[normalized(i) for i in v];return sorted(x,key=lambda i:json.dumps(i,sort_keys=True)) if key in ('allowedCapabilities','publicArgumentKeys','requiredRoles','required','enum') else x
    if key=='inputSchema' and isinstance(v,str):return normalized(json.loads(v))
    return v
def protected():
    p=l.read(HERE/'protected.json');orig=ROOT.parent/'enterprise-agent'
    assert l.digest(orig/'src/main/java/com/agent/platform/procurement/tool/ProcurementToolHandler.java')==p['old_handler']
    assert subprocess.check_output(['git','status','--short'],cwd=orig).decode()==p['original_status']
    assert subprocess.check_output(['git','show-ref','--tags']).decode()==p['tags']
    assert all(l.digest(Path(k))==v for k,v in p['holdout_files'].items()),'Holdout-v1 altered'
def freeze():
    env=l.model_env();v=h.freeze()
    v['production_raw']={p:l.digest(ROOT/p) for p in v['production']['files']}
    v['compiled']={p.relative_to(ROOT).as_posix():l.digest(p) for f in ('target/classes','target/test-classes') for p in (ROOT/f).rglob('*.class')}
    v['scripts']={p.name:l.digest(p) for p in (HERE/'run_regression.py',HERE/'EvalPreflight.java',HERE/'observations.py')}
    v['env']=l.canonical_hash({k:v for k,v in env.items() if k.startswith(('DEEPSEEK','AGENT_','ERPNEXT','SPRING_','PROCUREMENT_'))})
    return v
def readiness():
    assert not BASE.exists();BASE.mkdir()
    protected()
    results=l.read(next((ROOT/'target/procurement-v0').glob('*/results.json')))
    assert {x['phase'] for x in results}=={'procurement','replay','full','build'}
    # Preserve the failed historical Full run; require the explicitly archived A/B Full rerun.
    assert all(x['exitCode']==0 and x['failures']==0 and x['errors']==0 for x in results if x['phase']!='full')
    current_full=l.read(HERE/'mcp-ab-20261006/full-results.json')
    assert current_full['tests']==1255 and current_full['exitCode']==0 and current_full['failures']==current_full['errors']==0
    for variant in ('baseline','context'):
        assert l.read(HERE/'mcp-ab-20261006'/ (variant+'-result.json'))['exit_code']==0
    frozen_source=l.read(HERE/'mcp-ab-20261006/source-before.json')
    assert all(l.digest(ROOT/p)==v for p,v in frozen_source['files'].items())
    assert 'Tests run: 66, Failures: 0, Errors: 0, Skipped: 0' in (HERE/'focused-final.log').read_text(encoding='utf-8',errors='replace')
    assert all(l.digest(ROOT/x['path'])==x['sha256'] for x in l.read(ROOT/'evals/regression/legacy-v1/fixtures.json')['files'])
    cp=str(ROOT/'target/test-classes')+os.pathsep+str(ROOT/'target/classes')+os.pathsep+(ROOT/'target/procurement-v2-classpath.txt').read_text().strip()
    q=lambda x:'"'+str(x).replace('\\','/')+'"'
    af=BASE/'preflight.args';af.write_text('-cp\n'+q(cp)+'\n'+q(HERE/'EvalPreflight.java')+'\n'+q(BASE/'controls.json')+'\n',encoding='utf-8')
    env=l.model_env();env['TEMP']=env['TMP']=str(ROOT/'target/procurement-v2/jvm-temp')
    l.command(['java','@'+str(af)],BASE/'preflight.log',120,env)
    old=ROOT.parent/'enterprise-agent-reliability-v1-clean/target/harness-reliability/holdout-20261005-r1/controls.json'
    assert normalized(l.read(BASE/'controls.json'))==normalized(l.read(old)),'Prompt/model/schema/trust/budget changed'
    l.write(BASE/'freeze.json',freeze())
    folder=BASE/'readiness';folder.mkdir();s=h.world(TASK,folder,'reset');assert not s['rfqs']
    l.write(BASE/'readiness.json',dict(status='PASS',controls_unchanged=True,seed_hash=s['baseCanonicalBusinessHash'],counts=s['counts'],provider_calls=0))
    assert freeze()==l.read(BASE/'freeze.json');protected();print('READINESS PASS: exposed ROB-04 regression only; 0 model calls',flush=True)
def run():
    assert l.read(BASE/'readiness.json')['status']=='PASS';assert not (BASE/'result.json').exists() and not (BASE/'ROB-04-1-a1').exists()
    assert freeze()==l.read(BASE/'freeze.json');protected()
    print('START Holdout-v1 ROB-04 regression x1 (EXPOSED)',flush=True)
    row=h.trial(TASK,BASE/'ROB-04-1-a1');l.write(BASE/'result.json',row)
    assert freeze()==l.read(BASE/'freeze.json');protected()
    if (BASE/'ROB-04-1-a1/raw.json').exists():
        from observations import observe
        raw=l.read(BASE/'ROB-04-1-a1/raw.json');l.write(BASE/'observations.json',observe(row,raw))
        l.write(BASE/'recovery-events.json',[e for e in raw['events'] if e['type'] in ('CONTEXT_PREPARED','CONTEXT_COMPACTED')])
    l.write(BASE/'complete.json',dict(executed=1,source_unchanged=True,stop_after_this_trial=True,exposed_regression=True,original_holdout='11/12'))
    print(json.dumps({k:row.get(k) for k in ('status','passed','failure_reason','invariant_violations','tool_calls','input_tokens','output_tokens','total_tokens')},ensure_ascii=False),flush=True)
if __name__=='__main__':
    assert sys.argv[1] in ('readiness','run')
    readiness() if sys.argv[1]=='readiness' else run()
