from pathlib import Path
import os,json,hashlib,subprocess,time,sys,tempfile,shutil
R=Path(__file__).resolve().parents[3]; O=Path(__file__).parent; B=R.parent/'enterprise-agent-reliability-v1-diagnostic'
def h(b):return hashlib.sha256(b).hexdigest()
def canon(v):return h(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def snapshot(root):
    files={p.relative_to(root).as_posix():h(p.read_bytes()) for folder in ('src','evals','data') for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    prod={p.relative_to(root).as_posix():h(p.read_bytes().replace(b'\r\n',b'\n')) for p in sorted((root/'src/main').rglob('*.java'))+sorted((root/'src/main/resources').rglob('*.yaml'))}
    return {'files':files,'production':{'sha256':canon(prod),'files':prod}}
mode=sys.argv[1]
if mode=='freeze':
    write(O/'source-before.json',snapshot(R));write(O/'baseline-before.json',snapshot(B))
    env=dict(os.environ);write(O/'environment.json',{'environment_sha256':canon(env),'variable_hashes':{k:h(v.encode()) for k,v in env.items()},'java_home':env.get('JAVA_HOME'),'path':env.get('PATH'),'temp':tempfile.gettempdir(),'maven':shutil.which('mvn'),'baseline_cwd':str(B),'context_cwd':str(R)})
    print('production fingerprint',snapshot(R)['production']['sha256'])
elif mode in ('baseline','context'):
    root=B if mode=='baseline' else R
    assert snapshot(R)==json.loads((O/'source-before.json').read_text(encoding='utf-8'))
    assert snapshot(B)==json.loads((O/'baseline-before.json').read_text(encoding='utf-8'))
    assert canon(dict(os.environ))==json.loads((O/'environment.json').read_text(encoding='utf-8'))['environment_sha256'],'environment changed'
    command=[shutil.which('mvn'),'-B','-Dtest=StdioMcpToolGatewayTests#refreshFailureInOneServerDoesNotAffectAnotherServer','-Dsurefire.reportNameSuffix=context-ab-1','test']
    log=O/(mode+'.log');assert not log.exists()
    events={};t0=time.time();temp=Path(tempfile.gettempdir());seen=set(temp.glob('enterprise-agent-mcp-*'))
    with log.open('w',encoding='utf-8') as out:
        p=subprocess.Popen(command,cwd=root,stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ))
        while p.poll() is None:
            for d in temp.glob('enterprise-agent-mcp-*'):
                if d in seen:continue
                e=events.setdefault(str(d),{'first_seen_epoch':time.time(),'files':{}})
                for f in d.glob('*'):
                    try:
                        if f.is_file():
                            content=f.read_text(errors='replace');old=e['files'].get(f.name)
                            if not old or old['content']!=content:e['files'][f.name]={'observed_epoch':time.time(),'mtime':f.stat().st_mtime,'content':content}
                    except OSError:pass
            time.sleep(.02)
    result={'command':command,'cwd':str(root),'exit_code':p.returncode,'start_epoch':t0,'end_epoch':time.time(),'env_sha256':canon(dict(os.environ)),'events':events}
    write(O/(mode+'-result.json'),result)
    print(mode,'exit',p.returncode,'elapsed',round(result['end_epoch']-t0,2),'captured directories',len(events),flush=True)

