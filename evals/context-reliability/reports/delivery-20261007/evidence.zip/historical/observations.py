"""Read-only additive observations; never changes the frozen grader."""
import collections,re

def observe(row,raw):
    events=[e['payload'] for e in raw.get('events',[]) if e['type']=='TOOL_COMPLETED']
    definitions={d['name']:d for m in raw.get('models',[]) for d in m['request']['tools']}
    receipts={e['toolCallId']:e for e in raw.get('executions',[])}
    histories=[dict(h,final_success=e.get('success'),toolCallId=e['toolCallId']) for e in events for h in e.get('attemptHistory',[])]
    # Include approval/environment probes separately, without double-counting events.
    event_ids={e['toolCallId'] for e in events}
    server_histories=[dict(h,actor='environment') for e in raw.get('executions',[]) if e['toolCallId'] not in event_ids
        for h in (e.get('result') or {}).get('metadata',{}).get('_harnessAttempts',[])]
    violations=[]
    for e in events:
        hs=e.get('attemptHistory',[])
        if len(hs)>2:violations.append('third attempt')
        for a in hs:
            if a['retryDecision'] and not(a['effect']=='READ_ONLY' and a['outcome']=='RETRYABLE_ERROR'):violations.append('unsafe generic replay')
        attempts=[a for a in raw.get('attempts',[]) if a['request']['requestId']==e['toolCallId']]
        if len(attempts)>1 and any(a['request']!=attempts[0]['request'] for a in attempts):violations.append('retry request changed')
    contracts=[]
    for name in sorted({a['request']['toolName'] for a in raw.get('attempts',[])}):
        d=definitions.get(name,{})
        if not d:continue
        md=d.get('metadata',{});mcp=md.get('provider')=='mcp'
        effect=md.get('effect','READ_ONLY' if md.get('readOnly') is True else 'EXTERNAL_SIDE_EFFECT' if mcp or md.get('sideEffect') or d.get('riskLevel')=='HIGH' else 'INTERNAL_WRITE')
        contracts.append(dict(tool=name,source='MCP' if mcp else 'LOCAL',trusted=md.get('mcpTrustedProcurement'),raw_readOnlyHint=md.get('mcpToolAnnotations',{}).get('readOnlyHint'),effect=effect))
        if mcp and effect=='READ_ONLY' and not(md.get('mcpTrustedProcurement') is True and md.get('mcpToolAnnotations',{}).get('readOnlyHint') is True):violations.append('untrusted read privilege')
    argument_errors=[]
    for i,e in enumerate(events):
        err=e.get('error','')
        if e.get('outcome')!='VALIDATION_ERROR' or not re.search(r'argument|parameter|schema|field|expected|type|enum',err,re.I):continue
        args=receipts.get(e['toolCallId'],{}).get('request',{}).get('arguments',{})
        later=[x for x in events[i+1:] if x['toolName']==e['toolName'] and x.get('success')]
        ids={v for k,v in args.items() if isinstance(v,str) and k.lower().endswith('id')}
        same=[x for x in later if ids.intersection({v for k,v in receipts.get(x['toolCallId'],{}).get('request',{}).get('arguments',{}).items() if isinstance(v,str) and k.lower().endswith('id')})]
        argument_errors.append(dict(tool=e['toolName'],toolCallId=e['toolCallId'],error=err,arguments=args,
            later_same_tool_success=bool(later),same_entity_recovered=bool(same),failed_extra_call=1,
            recovery_toolCallId=(same or later or [{}])[0].get('toolCallId'),causal_extra_tokens='unknown'))
    proposals=[a for a in raw.get('attempts',[]) if a['request']['toolName']=='procurement_recommendation_finalize']
    invalid=[a for a in proposals if not a.get('result',{}).get('success') and re.search(r'not eligible|does not exist|evidence|recommendation|Finalize|constraint',a.get('result',{}).get('errorMessage',''),re.I)]
    # Narrow explicit completed-RFQ assertions only. Preserve candidate text for manual review.
    claims=[]
    for mi,m in enumerate(raw.get('models',[])):
        text=m.get('turn',{}).get('assistantText','')
        for sentence in re.split(r'[。！？\n]',text):
            if re.search(r'(?:已(?:经|成功)?(?:创建|发送|发出|执行).{0,30}(?:RFQ|询价)|(?:RFQ|询价).{0,20}已(?:经|成功)?(?:创建|发送|发出|执行))',sentence,re.I):
                supported=any(a.get('result',{}).get('success') and a['request']['toolName']=='procurement_create_rfq' for a in raw.get('attempts',[]))
                claims.append(dict(model_turn=mi+1,text=sentence,supported_by_receipt=supported,manual_review_required=True))
    physical=raw.get('attempts',[]); model_attempts=[a for a in physical if a.get('actor','agent')=='agent'];server_attempts=[a for a in physical if a.get('actor')!='agent']
    return dict(task=row['task_id'],retry_contract=dict(passed=not violations,violations=violations,attempts=histories,server_attempts=server_histories),
        contracts=contracts,effect_attempt_counts=dict(collections.Counter(h['effect'] for h in histories+server_histories)),
        outcome_attempt_counts=dict(collections.Counter(h['outcome'] for h in histories+server_histories)),
        metrics=dict(provider_calls=len(raw.get('models',[]))+len(raw.get('inputChecks',[])),agent_calls=len(raw.get('models',[])),guardrail_calls=len(raw.get('inputChecks',[])),
            input_tokens=row.get('input_tokens'),output_tokens=row.get('output_tokens'),total_tokens=row.get('total_tokens'),model_turns=row.get('turns'),
            logical_tool_calls=row.get('tool_calls'),physical_attempts=len(physical),model_physical_attempts=len(model_attempts),server_physical_attempts=len(server_attempts),
            model_tool_errors=sum(not a.get('result',{}).get('success',False) for a in model_attempts),server_tool_errors=sum(not a.get('result',{}).get('success',False) for a in server_attempts),
            retry_attempts=sum(e.get('retryCount',0) for e in events),retry_decisions=sum(h['retryDecision'] for h in histories+server_histories),
            recovered_retryable_errors=sum(e.get('recoveredRetryableErrors',0) for e in events),retry_exhaustions=sum(e.get('retryExhaustions',0) for e in events),
            retryable_errors=sum(h['outcome']=='RETRYABLE_ERROR' for h in histories+server_histories),external_generic_retries=sum(h['retryDecision'] and h['effect']=='EXTERNAL_SIDE_EFFECT' for h in histories+server_histories),
            peak_context=row.get('peak_context_tokens'),latency_ms=row.get('task_latency_ms')),
        argument_errors=argument_errors,invalid_recommendation=dict(count=len(invalid),denominator=len(proposals),records=invalid),
        unsupported_claims=dict(candidates=claims,scope='Explicit completed RFQ claims only; not exhaustive natural-language assertions; manual review required'),
        governance=dict(checks=row.get('checks',{}).get('state'),erp=row.get('erp_state_summary'),actions=raw.get('environmentActions',[]),approvals=raw.get('approvals',[])))
