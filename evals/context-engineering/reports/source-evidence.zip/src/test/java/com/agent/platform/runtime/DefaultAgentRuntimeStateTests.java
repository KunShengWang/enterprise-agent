package com.agent.platform.runtime;

import com.agent.platform.agent.AgentRequest;
import com.agent.platform.approval.ApprovalRecord;
import com.agent.platform.approval.ApprovalService;
import com.agent.platform.approval.ApprovalStatus;
import com.agent.platform.config.AgentProperties;
import com.agent.platform.guardrail.GuardrailDecision;
import com.agent.platform.guardrail.GuardrailAction;
import com.agent.platform.guardrail.GuardrailService;
import com.agent.platform.guardrail.GuardrailStage;
import com.agent.platform.memory.MemoryService;
import com.agent.platform.llm.ConfiguredLlmCostCalculator;
import com.agent.platform.llm.LlmUsage;
import com.agent.platform.llm.LlmCallException;
import com.agent.platform.tool.ToolCallRequest;
import com.agent.platform.tool.ToolCallResult;
import com.agent.platform.tool.ToolDefinition;
import com.agent.platform.tool.ToolRiskLevel;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SuppressWarnings("unchecked")
class DefaultAgentRuntimeStateTests {

    @Test
    void repeatedModelToolCallIdsReceiveDifferentRuntimeExecutionIds() {
        Fixture fixture = new Fixture();
        AgentToolCall modelCall = new AgentToolCall(
                "call-1", "ticket_close", Map.of("id", "T1"), "close ticket"
        );

        AgentToolCall firstRunCall = fixture.runtime().assignExecutionId(modelCall);
        AgentToolCall secondRunCall = fixture.runtime().assignExecutionId(modelCall);

        assertNotEquals(modelCall.toolCallId(), firstRunCall.toolCallId());
        assertNotEquals(firstRunCall.toolCallId(), secondRunCall.toolCallId());
        assertEquals(modelCall.toolName(), firstRunCall.toolName());
        assertEquals(modelCall.arguments(), firstRunCall.arguments());
    }

    @Test
    void failedResumeClaimReturnsCurrentStateWithoutExecutingTool() {
        Fixture fixture = new Fixture();
        AgentRunLimits limits = AgentRunLimits.from(fixture.properties);
        AgentExecutionProfile profile = new AgentExecutionProfile(
                "restricted", "prompt", Set.of("ticket_status"), limits, false
        );
        ToolCallRequest request = new ToolCallRequest("ticket_status", "call-1", Map.of("id", "T1"));
        AgentRunRecord waiting = AgentRunRecord.create(
                        "run-1", "run-1", "session-1",
                        new AgentRequest("session-1", "user-1", "question", Map.of()),
                        profile, new AgentRunBudget(limits).snapshot())
                .waitingForApproval("approval-1", request, List.of(), List.of(), false,
                        new AgentRunBudget(limits).snapshot());
        AgentRunRecord alreadyClaimed = waiting.claimedForResume();
        ApprovalRecord approval = new ApprovalRecord(
                "approval-1", "run-1", "session-1", request, "reason",
                ApprovalStatus.APPROVED, "reviewer", "ok", Instant.now(), Instant.now()
        );
        when(fixture.runStore.find("run-1"))
                .thenReturn(Optional.of(waiting), Optional.of(alreadyClaimed));
        when(fixture.runStore.claimForResume("run-1")).thenReturn(Optional.empty());
        when(fixture.approvalService.find("approval-1")).thenReturn(Optional.of(approval));

        AgentRuntimeResult result = fixture.runtime().resume("run-1", AgentEventListener.NOOP);

        assertEquals(AgentRunState.RUNNING, result.state());
        verify(fixture.toolRuntime, never()).executeApproved(any(), any(), any());
        verify(fixture.runControlStore).acquireSessionLease(anyString(), anyString(), anyString(), any());
        verify(fixture.runControlStore).releaseSessionLease(anyString(), anyString());
    }

    @Test
    void unexpectedFailureConvergesPersistedRunToFailed() {
        Fixture fixture = new Fixture();
        AtomicReference<AgentRunRecord> persisted = new AtomicReference<>();
        when(fixture.runStore.create(any())).thenAnswer(invocation -> {
            AgentRunRecord record = invocation.getArgument(0);
            persisted.set(record);
            return record;
        });
        when(fixture.runStore.find(anyString())).thenAnswer(invocation -> Optional.ofNullable(persisted.get()));
        when(fixture.runStore.update(anyString(), any())).thenAnswer(invocation -> {
            java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
            AgentRunRecord updated = updater.apply(persisted.get());
            persisted.set(updated);
            return updated;
        });
        when(fixture.contextManager.project(anyString(), anyString(), anyString(), anyString(), anyLong(), any(AgentExecutionProfile.class)))
                .thenThrow(new IllegalStateException("context database failed"));

        AgentRuntimeResult result = fixture.runtime().run(
                new AgentRequest("session-1", "user-1", "question", Map.of()),
                AgentEventListener.NOOP
        );

        assertEquals(AgentRunState.FAILED, result.state());
        assertEquals(AgentStopReason.INTERNAL_ERROR, result.stopReason());
        assertEquals(AgentRunState.FAILED, persisted.get().state());
        verify(fixture.runControlStore).releaseSessionLease(anyString(), anyString());
    }

    @Test
    void userPauseResumesTheSameRunIdFromPersistedCheckpoint() throws Exception {
        Fixture fixture = new Fixture();
        AtomicBoolean pauseSignal = new AtomicBoolean(false);
        AtomicInteger modelCalls = new AtomicInteger();
        CountDownLatch firstModelStarted = new CountDownLatch(1);
        CountDownLatch releaseFirstModel = new CountDownLatch(1);

        when(fixture.runStore.create(any())).thenAnswer(invocation -> {
            AgentRunRecord created = invocation.getArgument(0);
            fixture.persisted.set(created);
            return created;
        });
        when(fixture.runStore.find(anyString()))
                .thenAnswer(invocation -> Optional.ofNullable(fixture.persisted.get()));
        when(fixture.runStore.update(anyString(), any())).thenAnswer(invocation -> {
            java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
            AgentRunRecord updated = updater.apply(fixture.persisted.get());
            fixture.persisted.set(updated);
            return updated;
        });
        when(fixture.runStore.claimPausedForResume(anyString())).thenAnswer(invocation -> {
            AgentRunRecord current = fixture.persisted.get();
            if (current == null || current.state() != AgentRunState.PAUSED) {
                return Optional.empty();
            }
            AgentRunRecord claimed = current.claimedPausedForResume();
            fixture.persisted.set(claimed);
            return Optional.of(claimed);
        });
        when(fixture.runControlStore.requestPause(anyString())).thenAnswer(invocation -> {
            pauseSignal.set(true);
            return true;
        });
        when(fixture.runControlStore.pauseRequested(anyString())).thenAnswer(invocation -> pauseSignal.get());
        when(fixture.runControlStore.clearPauseRequest(anyString())).thenAnswer(invocation -> {
            pauseSignal.set(false);
            return true;
        });
        when(fixture.contextManager.project(anyString(), anyString(), anyString(), anyString(), anyLong(), any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(List.of(), 0, 0, false));
        when(fixture.modelGateway.nextTurn(any())).thenAnswer(invocation -> {
            int call = modelCalls.incrementAndGet();
            if (call == 1) {
                firstModelStarted.countDown();
                assertTrue(releaseFirstModel.await(5, TimeUnit.SECONDS));
                return finalTurn("first model result must not complete the paused run");
            }
            return finalTurn("resumed from the same checkpoint");
        });

        DefaultAgentRuntime runtime = fixture.runtime();
        CompletableFuture<AgentRuntimeResult> firstExecution = CompletableFuture.supplyAsync(() -> runtime.run(
                new AgentRequest("session-pause", "user-1", "long running task", Map.of()),
                AgentEventListener.NOOP
        ));

        assertTrue(firstModelStarted.await(5, TimeUnit.SECONDS));
        String originalRunId = fixture.persisted.get().runId();
        assertTrue(runtime.pause(originalRunId));
        releaseFirstModel.countDown();

        AgentRuntimeResult paused = firstExecution.get(5, TimeUnit.SECONDS);
        assertEquals(originalRunId, paused.runId());
        assertEquals(AgentRunState.PAUSED, paused.state());
        assertEquals(AgentStopReason.PAUSED, paused.stopReason());
        assertEquals(AgentRunPhase.MODEL_CALL, fixture.persisted.get().phase());
        assertTrue(fixture.persisted.get().budgetSnapshot().executionPaused());

        AgentRuntimeResult resumed = runtime.resume(originalRunId, AgentEventListener.NOOP);

        assertEquals(originalRunId, resumed.runId());
        assertEquals(AgentRunState.COMPLETED, resumed.state());
        assertEquals("resumed from the same checkpoint", resumed.answer());
        assertEquals(1, fixture.persisted.get().resumeCount());
        assertEquals(2, modelCalls.get());
        verify(fixture.runStore).claimPausedForResume(originalRunId);
    }

    @Test
    void pauseRequestedCheckpointCanRecoverAfterTheOriginalWorkerDisappears() {
        Fixture fixture = new Fixture();
        AgentRunLimits limits = AgentRunLimits.from(fixture.properties);
        AgentRunBudget budget = new AgentRunBudget(limits);
        budget.pauseExecution();
        AgentRunRecord pauseRequested = AgentRunRecord.create(
                        "run-pause-requested", "run-pause-requested", "session-pause-requested",
                        new AgentRequest("session-pause-requested", "user-1", "continue after crash", Map.of()),
                        new AgentExecutionProfile("default", "prompt", Set.of(), limits, false),
                        budget.snapshot())
                .pauseRequested(budget.snapshot());
        fixture.persisted.set(pauseRequested);
        when(fixture.runStore.find("run-pause-requested"))
                .thenAnswer(invocation -> Optional.of(fixture.persisted.get()));
        when(fixture.runStore.claimPausedForResume("run-pause-requested")).thenAnswer(invocation -> {
            AgentRunRecord claimed = fixture.persisted.get().claimedPausedForResume();
            fixture.persisted.set(claimed);
            return Optional.of(claimed);
        });
        when(fixture.runStore.update(anyString(), any())).thenAnswer(invocation -> {
            java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
            AgentRunRecord updated = updater.apply(fixture.persisted.get());
            fixture.persisted.set(updated);
            return updated;
        });
        when(fixture.runControlStore.clearPauseRequest("run-pause-requested")).thenReturn(true);
        when(fixture.contextManager.project(anyString(), anyString(), anyString(), anyString(), anyLong(), any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(List.of(), 0, 0, false));
        when(fixture.modelGateway.nextTurn(any())).thenReturn(finalTurn("recovered after pause request crash"));

        AgentRuntimeResult resumed = fixture.runtime().resume(
                "run-pause-requested", AgentEventListener.NOOP
        );

        assertEquals("run-pause-requested", resumed.runId());
        assertEquals(AgentRunState.COMPLETED, resumed.state());
        assertEquals("recovered after pause request crash", resumed.answer());
        assertEquals(1, fixture.persisted.get().resumeCount());
    }

    @Test
    void abandoningPausedRunClosesPendingToolCallForTheNextConversationRun() {
        Fixture fixture = new Fixture();
        AgentRunLimits limits = AgentRunLimits.from(fixture.properties);
        AgentRunBudget budget = new AgentRunBudget(limits);
        ToolCallRequest pending = new ToolCallRequest(
                "ticket_close", "tool-call-abandoned", Map.of("id", "T1")
        );
        AgentRunRecord paused = AgentRunRecord.create(
                        "run-abandoned", "run-abandoned", "session-shared",
                        new AgentRequest("session-shared", "user-1", "close ticket", Map.of()),
                        new AgentExecutionProfile("restricted", "prompt", Set.of("ticket_close"), limits, false),
                        budget.snapshot())
                .checkpoint(
                        AgentRunPhase.EXECUTING_TOOL, pending, List.of(), List.of(), false, budget.snapshot()
                );
        budget.pauseExecution();
        fixture.persisted.set(paused.paused(budget.snapshot()));
        when(fixture.runStore.find("run-abandoned"))
                .thenAnswer(invocation -> Optional.of(fixture.persisted.get()));
        when(fixture.runStore.update(anyString(), any())).thenAnswer(invocation -> {
            java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
            AgentRunRecord updated = updater.apply(fixture.persisted.get());
            fixture.persisted.set(updated);
            return updated;
        });
        when(fixture.runControlStore.requestCancellation("run-abandoned")).thenReturn(true);
        when(fixture.timelineStore.loadMessages("session-shared", 10_000)).thenReturn(List.of());

        boolean cancelled = fixture.runtime().cancel("run-abandoned");

        assertTrue(cancelled);
        assertEquals(AgentRunState.REJECTED, fixture.persisted.get().state());
        assertEquals(1, fixture.persisted.get().toolResults().size());
        ToolCallResult closure = fixture.persisted.get().toolResults().get(0);
        assertEquals("RUN_ABANDONED", closure.metadata().get("outcome"));
        assertEquals(false, closure.metadata().get("outcomeKnown"));
        verify(fixture.timelineStore).appendMessages(
                anyString(), anyString(), anyString(),
                org.mockito.ArgumentMatchers.argThat(messages -> messages.size() == 1
                        && messages.get(0).type() == AgentMessageType.TOOL_RESULT
                        && "tool-call-abandoned".equals(messages.get(0).toolCallId()))
        );
        verify(fixture.toolRuntime, never()).execute(anyString(), anyString(), anyString(), any(), any(), any());
        verify(fixture.toolRuntime, never()).reconcileUncertain(any());
    }

    @Test
    void providerDeltasBecomeGuardedAndPersistedModelDeltaEvents() {
        Fixture fixture = new Fixture();
        fixture.properties.setStreamModelDeltaMinChars(4);
        fixture.properties.setStreamOutputGuardrailHoldbackChars(16);
        AtomicLong sequence = new AtomicLong();
        List<AgentEvent> delivered = new ArrayList<>();
        String first = "abcdefghijklmnopqrst";
        String second = "uvwxyz0123456789ABCD";
        String answer = first + second;

        when(fixture.runStore.create(any())).thenAnswer(invocation -> {
            AgentRunRecord created = invocation.getArgument(0);
            fixture.persisted.set(created);
            return created;
        });
        when(fixture.runStore.find(anyString()))
                .thenAnswer(invocation -> Optional.ofNullable(fixture.persisted.get()));
        when(fixture.runStore.update(anyString(), any())).thenAnswer(invocation -> {
            java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
            AgentRunRecord updated = updater.apply(fixture.persisted.get());
            fixture.persisted.set(updated);
            return updated;
        });
        when(fixture.contextManager.project(anyString(), anyString(), anyString(), anyString(), anyLong(), any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(List.of(), 0, 0, false));
        org.mockito.Mockito.doAnswer(invocation -> {
                    AgentEventDraft draft = invocation.getArgument(3);
                    return new AgentEvent(
                            "event-" + sequence.incrementAndGet(),
                            invocation.getArgument(2),
                            invocation.getArgument(0),
                            sequence.get(),
                            draft.type(),
                            draft.content(),
                            draft.payload(),
                            Instant.now()
                    );
                })
                .when(fixture.timelineStore)
                .appendEvent(anyString(), anyString(), anyString(), any());
        org.mockito.Mockito.doAnswer(invocation -> {
            AgentModelDeltaListener deltaListener = invocation.getArgument(1);
            deltaListener.onDelta(first);
            deltaListener.onDelta(second);
            return finalTurn(answer);
        }).when(fixture.modelGateway).nextTurn(any(), any());

        AgentRuntimeResult result = fixture.runtime().run(
                new AgentRequest("session-stream", "user-1", "stream answer", Map.of()),
                delivered::add
        );

        assertEquals(AgentRunState.COMPLETED, result.state());
        assertEquals(answer, result.answer());
        List<AgentEvent> deltas = delivered.stream()
                .filter(event -> event.type() == AgentEventType.MODEL_DELTA)
                .toList();
        assertTrue(deltas.size() >= 2);
        assertEquals(answer, deltas.stream().map(AgentEvent::content).reduce("", String::concat));
        assertTrue(deltas.stream().allMatch(event -> event.sequence() > 0));
    }

    @Test
    void protocolFailureRetriesOnceWithinModelBudgetAndThenCompletes() {
        Fixture fixture = new Fixture();
        fixture.properties.setMaxModelProtocolRetries(1);
        AtomicInteger calls = new AtomicInteger();
        List<AgentEvent> delivered = new ArrayList<>();
        List<AgentEventDraft> drafts = new ArrayList<>();

        when(fixture.runStore.create(any())).thenAnswer(invocation -> {
            AgentRunRecord created = invocation.getArgument(0);
            fixture.persisted.set(created);
            return created;
        });
        when(fixture.runStore.find(anyString()))
                .thenAnswer(invocation -> Optional.ofNullable(fixture.persisted.get()));
        when(fixture.runStore.update(anyString(), any())).thenAnswer(invocation -> {
            java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
            AgentRunRecord updated = updater.apply(fixture.persisted.get());
            fixture.persisted.set(updated);
            return updated;
        });
        when(fixture.contextManager.project(anyString(), anyString(), anyString(), anyString(), anyLong(), any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(List.of(), 0, 0, false));
        org.mockito.Mockito.doAnswer(invocation -> {
            AgentEventDraft draft = invocation.getArgument(3);
            drafts.add(draft);
            return new AgentEvent("event-" + drafts.size(), invocation.getArgument(2),
                    invocation.getArgument(0), drafts.size(), draft.type(), draft.content(),
                    draft.payload(), Instant.now());
        }).when(fixture.timelineStore).appendEvent(anyString(), anyString(), anyString(), any());
        org.mockito.Mockito.doAnswer(invocation -> {
            if (calls.incrementAndGet() == 1) {
                throw new LlmCallException("MODEL_PROTOCOL_ERROR", "invalid protocol", null);
            }
            AgentModelDeltaListener listener = invocation.getArgument(1);
            listener.onDelta("retry succeeded");
            return finalTurn("retry succeeded");
        }).when(fixture.modelGateway).nextTurn(any(), any());

        AgentRuntimeResult result = fixture.runtime().run(
                new AgentRequest("session-protocol", "user-1", "question", Map.of()),
                delivered::add
        );

        assertEquals(AgentRunState.COMPLETED, result.state());
        assertEquals("retry succeeded", result.answer());
        assertEquals(2, calls.get());
        assertEquals(2, fixture.persisted.get().budgetSnapshot().modelCalls());
        assertTrue(drafts.stream().anyMatch(event -> event.type() == AgentEventType.MODEL_FAILED
                && Boolean.TRUE.equals(event.payload().get("recoverableByProtocolRetry"))));
        assertTrue(drafts.stream().anyMatch(event -> event.type() == AgentEventType.MODEL_STARTED
                && Integer.valueOf(1).equals(event.payload().get("protocolRetry"))));
    }

    @Test
    void existingSummaryDoesNotCountAsACompactionInTheCurrentTurn() {
        Fixture fixture = new Fixture();
        configureRunPersistence(fixture);
        List<AgentEventDraft> drafts = new ArrayList<>();
        recordEvents(fixture, drafts);
        when(fixture.contextManager.project(anyString(), anyString(), anyString(), anyString(), anyLong(), any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(
                        List.of(), 12, 0, true,
                        Map.of("coversThroughSequence", 17L, "compactionPerformed", false)
                ));
        when(fixture.modelGateway.nextTurn(any())).thenReturn(finalTurn("summary reused"));

        AgentRuntimeResult result = fixture.runtime().run(
                new AgentRequest("session-summary", "user-1", "question", Map.of()),
                AgentEventListener.NOOP
        );

        assertEquals(AgentRunState.COMPLETED, result.state());
        AgentEventDraft contextEvent = drafts.stream()
                .filter(event -> event.type() == AgentEventType.CONTEXT_PREPARED
                        || event.type() == AgentEventType.CONTEXT_COMPACTED)
                .findFirst()
                .orElseThrow();
        assertEquals(AgentEventType.CONTEXT_PREPARED, contextEvent.type());
        assertEquals("projection", contextEvent.payload().get("reason"));
        assertEquals(false, contextEvent.payload().get("compactionRequested"));
        assertEquals(false, contextEvent.payload().get("compactionPerformed"));
        assertEquals(24_000L, contextEvent.payload().get("tokenBudget"));
        assertEquals(17L, contextEvent.payload().get("coversThroughSequence"));
    }

    @Test
    void contextBudgetCompactionEventContainsBeforeAndAfterMetrics() {
        Fixture fixture = new Fixture();
        configureRunPersistence(fixture);
        List<AgentEventDraft> drafts = new ArrayList<>();
        recordEvents(fixture, drafts);
        when(fixture.contextManager.project(anyString(), anyString(), anyString(), anyString(), anyLong(), any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(
                        contextMessages(2), 20, 1, false,
                        Map.of("coversThroughSequence", 2L, "compactionPerformed", false)
                ));
        when(fixture.contextManager.compact(anyString(), anyString(), anyString(), anyString(), anyString(), anyLong(), anyString(), any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(
                        contextMessages(1), 8, 0, true,
                        Map.of("coversThroughSequence", 8L, "compactionPerformed", true,
                                "compactedMessageCount", 3)
                ));
        when(fixture.modelGateway.nextTurn(any())).thenReturn(finalTurn("compacted"));

        AgentRuntimeResult result = fixture.runtime().run(
                new AgentRequest("session-context-budget", "user-1", "question", Map.of()),
                AgentEventListener.NOOP
        );

        assertEquals(AgentRunState.COMPLETED, result.state());
        AgentEventDraft contextEvent = drafts.stream()
                .filter(event -> event.type() == AgentEventType.CONTEXT_COMPACTED)
                .findFirst()
                .orElseThrow();
        assertEquals("context_budget", contextEvent.payload().get("reason"));
        assertEquals(true, contextEvent.payload().get("compactionRequested"));
        assertEquals(true, contextEvent.payload().get("compactionPerformed"));
        assertEquals(24_000L, contextEvent.payload().get("tokenBudget"));
        assertEquals(2, contextEvent.payload().get("beforeMessageCount"));
        assertEquals(20L, contextEvent.payload().get("beforeEstimatedTokens"));
        assertEquals(1, contextEvent.payload().get("beforeOmittedMessages"));
        assertEquals(1, contextEvent.payload().get("afterMessageCount"));
        assertEquals(8L, contextEvent.payload().get("afterEstimatedTokens"));
        assertEquals(0, contextEvent.payload().get("afterOmittedMessages"));
        assertEquals(8L, contextEvent.payload().get("coversThroughSequence"));
    }

    @Test
    void providerContextOverflowCompactsOnceAndStopsAfterTheBoundedRetry() {
        Fixture fixture = new Fixture();
        fixture.properties.setMaxContextOverflowRetries(1);
        configureRunPersistence(fixture);
        List<AgentEventDraft> drafts = new ArrayList<>();
        recordEvents(fixture, drafts);
        when(fixture.contextManager.project(anyString(), anyString(), anyString(), anyString(), anyLong(), any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(List.of(), 10, 0, false));
        when(fixture.contextManager.compact(anyString(), anyString(), anyString(), anyString(), anyString(), anyLong(), anyString(), any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(
                        List.of(), 5, 0, true,
                        Map.of("coversThroughSequence", 9L, "compactionPerformed", true)
                ));
        AtomicInteger modelCalls = new AtomicInteger();
        org.mockito.Mockito.doAnswer(invocation -> {
            modelCalls.incrementAndGet();
            throw new LlmCallException("CONTEXT_OVERFLOW", "context too large", null);
        }).when(fixture.modelGateway).nextTurn(any(), any());

        AgentRuntimeResult result = fixture.runtime().run(
                new AgentRequest("session-overflow", "user-1", "question", Map.of()),
                AgentEventListener.NOOP
        );

        assertEquals(AgentRunState.FAILED, result.state());
        assertEquals(AgentStopReason.CONTEXT_OVERFLOW, result.stopReason());
        assertEquals(2, modelCalls.get());
        org.mockito.Mockito.verify(fixture.contextManager).compact(
                anyString(), anyString(), anyString(), anyString(), anyString(), anyLong(),
                org.mockito.ArgumentMatchers.eq("provider_context_overflow"), any(AgentExecutionProfile.class)
        );
        AgentEventDraft overflowEvent = drafts.stream()
                .filter(event -> event.type() == AgentEventType.CONTEXT_COMPACTED
                        && "provider_context_overflow".equals(event.payload().get("reason")))
                .findFirst()
                .orElseThrow();
        assertEquals(1, overflowEvent.payload().get("retry"));
        assertEquals(1, overflowEvent.payload().get("maxRetries"));
        assertEquals(24_000L, overflowEvent.payload().get("tokenBudget"));
        assertEquals(12_000L, overflowEvent.payload().get("retryBudget"));
        assertEquals(true, overflowEvent.payload().get("compactionPerformed"));
    }

    @Test
    void harnessUnknownToolReturnsToModelWithinSameRun() {
        Fixture fixture = harnessFixture();
        when(fixture.modelGateway.nextTurn(any())).thenReturn(toolTurn("missing"), finalTurn("recovered"));
        var events = new ArrayList<AgentEventDraft>(); recordEvents(fixture, events);
        var result = fixture.runtime().run(new AgentRequest("s", "u", "question", Map.of()), harnessProfile(fixture), AgentEventListener.NOOP);
        assertEquals(AgentStopReason.COMPLETED, result.stopReason());
        assertEquals(1, result.budget().toolCalls());
        assertTrue(events.stream().anyMatch(e -> "VALIDATION_ERROR".equals(e.payload().get("outcome"))));
        verify(fixture.toolRuntime, never()).execute(any(),any(),any(),any(),any(),any());
    }

    @Test
    void harnessUnknownToolLoopStopsAtToolBudget() {
        Fixture fixture = harnessFixture(); fixture.properties.setMaxToolCallsPerRun(1);
        when(fixture.modelGateway.nextTurn(any())).thenReturn(toolTurn("missing"));
        var result = fixture.runtime().run(new AgentRequest("s", "u", "question", Map.of()), harnessProfile(fixture), AgentEventListener.NOOP);
        assertEquals(AgentStopReason.TOOL_BUDGET_EXHAUSTED,result.stopReason());
        assertEquals(1,result.budget().toolCalls());
    }

    @Test
    void oversizedRequiredContextStopsBeforeModelCall() {
        Fixture fixture = harnessFixture();
        AgentMessage required = new AgentMessage("current", "s", "r", 1, AgentMessageType.USER,
                "required current task ".repeat(10000), "", "", Map.of(), Map.of(), 0, Instant.now());
        when(fixture.contextManager.project(anyString(),anyString(),anyString(),anyString(),anyLong(),any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(List.of(required),0,0,false));
        AgentExecutionProfile base = harnessProfile(fixture);
        AgentExecutionProfile bounded = new AgentExecutionProfile(base.name(),base.systemPrompt(),base.allowedCapabilities(),
                base.limits(),false,new ContextPolicy(true,32000,2000,0.75,2));
        var result = fixture.runtime().run(new AgentRequest("s","u","question",Map.of()),bounded,AgentEventListener.NOOP);
        assertEquals(AgentStopReason.CONTEXT_OVERFLOW,result.stopReason());
        verify(fixture.modelGateway,never()).nextTurn(any(),any());
        verify(fixture.toolRuntime,never()).execute(any(),any(),any(),any(),any(),any());
    }

    @Test
    void fatalModelErrorStopsWithoutToolExecutionOrAnotherModelTurn() {
        Fixture fixture = harnessFixture();
        doAnswer(invocation -> {
            throw new LlmCallException("MODEL_AUTH_ERROR", "model authentication rejected", null);
        }).when(fixture.modelGateway).nextTurn(any(), any());

        AgentRuntimeResult result = fixture.runtime().run(
                new AgentRequest("session-model-fatal", "user-1", "question", Map.of()),
                harnessProfile(fixture), AgentEventListener.NOOP);

        assertEquals(AgentStopReason.MODEL_ERROR, result.stopReason());
        assertEquals(RunStatus.FAILED, result.status());
        assertEquals(AgentRunState.FAILED, fixture.persisted.get().state());
        verify(fixture.modelGateway).nextTurn(any(), any());
        verify(fixture.toolRuntime, never()).execute(any(), any(), any(), any(), any(), any());
    }

    @Test
    void harnessFatalToolStopsBeforeAnotherModelInvocation() {
        Fixture fixture = harnessFixture();
        List<AgentRunRecord> checkpoints = new ArrayList<>();
        doAnswer(call -> {
            java.util.function.UnaryOperator<AgentRunRecord> update=call.getArgument(1);
            AgentRunRecord record=update.apply(fixture.persisted.get());
            checkpoints.add(record);fixture.persisted.set(record);return record;
        }).when(fixture.runStore).update(anyString(),any());
        ToolDefinition definition = new ToolDefinition("ticket_status","tool","{}",ToolRiskLevel.LOW,Map.of());
        when(fixture.capabilityRegistry.findCapability("ticket_status")).thenReturn(Optional.of(definition));
        when(fixture.modelGateway.nextTurn(any())).thenReturn(toolTurn("ticket_status"));
        when(fixture.toolRuntime.execute(any(),any(),any(),any(),any(),any())).thenAnswer(call -> {
            AgentToolCall requested = call.getArgument(4);
            return new AgentToolRuntimeResult(AgentToolExecutionStatus.FAILED,
                    new ToolCallRequest(requested.toolName(),requested.toolCallId(),Map.of()),
                    new ToolCallResult("ticket_status",false,"","failed",Map.of("_harnessOutcome","FATAL_ERROR")),
                    GuardrailAction.ALLOW,"ok","",false);
        });
        var result=fixture.runtime().run(new AgentRequest("s","u","question",Map.of()),harnessProfile(fixture),AgentEventListener.NOOP);
        assertEquals(AgentStopReason.TOOL_ERROR,result.stopReason());
        assertEquals(RunStatus.FAILED,result.status());
        verify(fixture.modelGateway).nextTurn(any());
        assertTrue(checkpoints.stream().noneMatch(r -> !r.toolResults().isEmpty()
                && r.phase()==AgentRunPhase.CONTEXT_PREPARATION));
    }

    @Test
    void persistedFatalToolResultStopsWithoutReexecutingOrReplanning() {
        Fixture fixture=new Fixture();
        var result=fixture.recoverCertainToolExecution(ToolExecutionState.FAILED,
                new ToolCallResult("ticket_close",false,"","fatal",Map.of("_harnessOutcome","FATAL_ERROR")));
        assertEquals(AgentStopReason.TOOL_ERROR,result.stopReason());
        assertEquals(RunStatus.FAILED,result.status());
        verify(fixture.modelGateway,never()).nextTurn(any(),any());
        verify(fixture.toolRuntime,never()).execute(any(),any(),any(),any(),any(),any());
    }

    private Fixture harnessFixture() {
        Fixture fixture=new Fixture(); configureRunPersistence(fixture);
        when(fixture.contextManager.project(anyString(),anyString(),anyString(),anyString(),anyLong(),any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(List.of(),0,0,false));
        return fixture;
    }

    private AgentModelTurn toolTurn(String name) {
        return new AgentModelTurn("",List.of(new AgentToolCall("call",name,Map.of(),"")),"",
                new LlmUsage(10,5,15,0,0,"test","test"),"tool_calls");
    }

    private AgentExecutionProfile harnessProfile(Fixture fixture) {
        return new AgentExecutionProfile("test", "prompt", Set.of("missing", "ticket_status"), AgentRunLimits.from(fixture.properties), false);
    }

    private static AgentModelTurn finalTurn(String answer) {
        return new AgentModelTurn(
                answer,
                List.of(),
                answer,
                new LlmUsage(10, 5, 15, 0, 0, "test-model", "test"),
                "stop"
        );
    }

    private void configureRunPersistence(Fixture fixture) {
        when(fixture.runStore.create(any())).thenAnswer(invocation -> {
            AgentRunRecord created = invocation.getArgument(0);
            fixture.persisted.set(created);
            return created;
        });
        when(fixture.runStore.find(anyString()))
                .thenAnswer(invocation -> Optional.ofNullable(fixture.persisted.get()));
        when(fixture.runStore.update(anyString(), any())).thenAnswer(invocation -> {
            java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
            AgentRunRecord updated = updater.apply(fixture.persisted.get());
            fixture.persisted.set(updated);
            return updated;
        });
    }

    private void recordEvents(Fixture fixture, List<AgentEventDraft> drafts) {
        org.mockito.Mockito.doAnswer(invocation -> {
            AgentEventDraft draft = invocation.getArgument(3);
            drafts.add(draft);
            return new AgentEvent(
                    "event-" + drafts.size(), invocation.getArgument(2), invocation.getArgument(0), drafts.size(),
                    draft.type(), draft.content(), draft.payload(), Instant.now()
            );
        }).when(fixture.timelineStore).appendEvent(anyString(), anyString(), anyString(), any());
    }

    private List<AgentMessage> contextMessages(int count) {
        List<AgentMessage> messages = new ArrayList<>();
        for (int index = 0; index < count; index++) {
            messages.add(new AgentMessage(
                    "context-message-" + index, "session-context", "run-context", index + 1,
                    AgentMessageType.USER, "context", "", "", Map.of(), Map.of(), 1, Instant.now()
            ));
        }
        return List.copyOf(messages);
    }

    @Test
    void parallelSafeSubAgentToolsRunConcurrentlyAndJoinBeforeNextModelTurn() throws Exception {
        Fixture fixture = new Fixture();
        fixture.properties.setMaxToolCallsPerRun(3);
        when(fixture.runStore.create(any())).thenAnswer(invocation -> {
            AgentRunRecord created = invocation.getArgument(0);
            fixture.persisted.set(created);
            return created;
        });
        when(fixture.runStore.find(anyString()))
                .thenAnswer(invocation -> Optional.ofNullable(fixture.persisted.get()));
        when(fixture.runStore.update(anyString(), any())).thenAnswer(invocation -> {
            java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
            AgentRunRecord updated = updater.apply(fixture.persisted.get());
            fixture.persisted.set(updated);
            return updated;
        });
        when(fixture.contextManager.project(anyString(), anyString(), anyString(), anyString(), anyLong(), any(AgentExecutionProfile.class)))
                .thenReturn(new AgentContextView(List.of(), 0, 0, false));
        ToolDefinition order = subAgentDefinition("delegate_order_analyst");
        ToolDefinition inventory = subAgentDefinition("delegate_inventory_analyst");
        when(fixture.capabilityRegistry.findCapability("delegate_order_analyst"))
                .thenReturn(Optional.of(order));
        when(fixture.capabilityRegistry.findCapability("delegate_inventory_analyst"))
                .thenReturn(Optional.of(inventory));

        AtomicInteger modelCalls = new AtomicInteger();
        when(fixture.modelGateway.nextTurn(any())).thenAnswer(invocation -> {
            if (modelCalls.incrementAndGet() == 1) {
                return new AgentModelTurn(
                        "",
                        List.of(
                                new AgentToolCall("provider-1", order.name(), Map.of("objective", "orders"), "delegate"),
                                new AgentToolCall("provider-2", inventory.name(), Map.of("objective", "inventory"), "delegate")),
                        "", new LlmUsage(10, 5, 15, 0, 0, "test-model", "test"), "tool_calls",
                        "delegate two specialists");
            }
            return finalTurn("joined");
        });

        CountDownLatch bothStarted = new CountDownLatch(2);
        AtomicInteger active = new AtomicInteger();
        AtomicInteger maxActive = new AtomicInteger();
        when(fixture.toolRuntime.execute(anyString(), anyString(), anyString(), any(), any(), any()))
                .thenAnswer(invocation -> {
                    AgentToolCall call = invocation.getArgument(4);
                    int current = active.incrementAndGet();
                    maxActive.accumulateAndGet(current, Math::max);
                    bothStarted.countDown();
                    assertTrue(bothStarted.await(5, TimeUnit.SECONDS));
                    active.decrementAndGet();
                    ToolCallRequest request = new ToolCallRequest(
                            call.toolName(), call.toolCallId(), call.arguments());
                    ToolCallResult result = new ToolCallResult(
                            call.toolName(), true, call.toolName() + " done", "", Map.of());
                    return new AgentToolRuntimeResult(
                            AgentToolExecutionStatus.COMPLETED, request, result,
                            GuardrailAction.ALLOW, "allowed", "", false);
                });

        AgentExecutionProfile profile = new AgentExecutionProfile(
                "parallel-subagents", "prompt", Set.of(order.name(), inventory.name()),
                AgentRunLimits.from(fixture.properties), false);
        AgentRuntimeResult result = fixture.runtime().run(
                new AgentRequest("session-parallel", "user-1", "investigate", Map.of()),
                profile, AgentEventListener.NOOP);

        assertEquals(AgentRunState.COMPLETED, result.state());
        assertEquals("joined", result.answer());
        assertEquals(2, maxActive.get());
        assertEquals(2, fixture.persisted.get().toolResults().size());
        assertEquals(2, fixture.persisted.get().budgetSnapshot().toolCalls());
        ArgumentCaptor<List<AgentMessageDraft>> draftsCaptor = ArgumentCaptor.forClass(List.class);
        verify(fixture.timelineStore, atLeastOnce()).appendMessages(
                anyString(), anyString(), anyString(), draftsCaptor.capture());
        List<AgentMessageDraft> toolCallDrafts = draftsCaptor.getAllValues().stream()
                .flatMap(List::stream)
                .filter(draft -> draft.type() == AgentMessageType.ASSISTANT_TOOL_CALL)
                .toList();
        assertEquals(2, toolCallDrafts.size());
        assertEquals(Set.of("provider-1", "provider-2"), toolCallDrafts.stream()
                .map(draft -> String.valueOf(draft.metadata().get(
                        AgentProviderMetadata.MODEL_TOOL_CALL_ID)))
                .collect(java.util.stream.Collectors.toSet()));
        assertTrue(toolCallDrafts.stream().allMatch(draft -> "delegate two specialists".equals(
                draft.metadata().get(AgentProviderMetadata.REASONING_CONTENT))));
    }

    private static ToolDefinition subAgentDefinition(String name) {
        return new ToolDefinition(
                name, "delegate", "{}", ToolRiskLevel.LOW,
                Map.of(
                        "readOnly", true,
                        "parallelSafe", true,
                        "singleUse", true,
                        "executionKind", "SUB_AGENT"));
    }

    @Test
    void staleToolExecutionCheckpointRequiresManualReviewInsteadOfRepeatingSideEffect() {
        Fixture fixture = new Fixture();
        AgentRunLimits limits = AgentRunLimits.from(fixture.properties);
        AgentExecutionProfile profile = new AgentExecutionProfile(
                "restricted", "prompt", Set.of("ticket_close"), limits, false
        );
        AgentRunBudget budget = new AgentRunBudget(limits);
        ToolCallRequest pending = new ToolCallRequest("ticket_close", "call-1", Map.of("id", "T1"));
        AtomicReference<AgentRunRecord> persisted = new AtomicReference<>(
                AgentRunRecord.create(
                                "run-1", "run-1", "session-1",
                                new AgentRequest("session-1", "user-1", "close ticket", Map.of()),
                                profile, budget.snapshot())
                        .checkpoint(AgentRunPhase.EXECUTING_TOOL, pending, List.of(), List.of(), false,
                                budget.snapshot())
        );
        when(fixture.runStore.find("run-1")).thenAnswer(invocation -> Optional.of(persisted.get()));
        when(fixture.runStore.update(anyString(), any())).thenAnswer(invocation -> {
            java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
            AgentRunRecord updated = updater.apply(persisted.get());
            persisted.set(updated);
            return updated;
        });

        AgentRuntimeResult result = fixture.runtime().resume("run-1", AgentEventListener.NOOP);

        assertEquals(AgentRunState.MANUAL_REVIEW, result.state());
        assertEquals(AgentRunState.MANUAL_REVIEW, persisted.get().state());
        assertEquals(1, persisted.get().toolResults().size());
        assertEquals("MANUAL_REVIEW", persisted.get().toolResults().get(0).metadata().get("outcome"));
        verify(fixture.timelineStore).appendMessages(
                anyString(), anyString(), anyString(),
                org.mockito.ArgumentMatchers.argThat(messages -> messages.size() == 1
                        && messages.get(0).type() == AgentMessageType.TOOL_RESULT
                        && "call-1".equals(messages.get(0).toolCallId()))
        );
        verify(fixture.toolRuntime, never()).execute(anyString(), anyString(), anyString(), any(), any(), any());
    }

    @Test
    void approvedManualReviewClosesToolPairBeforeRunTerminates() {
        Fixture fixture = new Fixture();
        AgentRunLimits limits = AgentRunLimits.from(fixture.properties);
        AgentExecutionProfile profile = new AgentExecutionProfile(
                "restricted", "prompt", Set.of("ticket_close"), limits, false
        );
        ToolCallRequest request = new ToolCallRequest("ticket_close", "call-review", Map.of("id", "T1"));
        AgentRunBudget budget = new AgentRunBudget(limits);
        AgentRunRecord waiting = AgentRunRecord.create(
                        "run-review", "run-review", "session-review",
                        new AgentRequest("session-review", "user-1", "close ticket", Map.of()),
                        profile, budget.snapshot())
                .waitingForApproval("approval-review", request, List.of(), List.of(), false, budget.snapshot());
        fixture.persisted.set(waiting);
        ApprovalRecord approval = new ApprovalRecord(
                "approval-review", "run-review", "session-review", request, "high risk",
                ApprovalStatus.APPROVED, "reviewer", "approved", Instant.now(), Instant.now().plusSeconds(60)
        );
        ToolDefinition definition = new ToolDefinition(
                "ticket_close", "close ticket", "{}", ToolRiskLevel.HIGH, Map.of()
        );
        ToolCallResult uncertain = new ToolCallResult(
                "ticket_close", false, "", "remote outcome is unknown",
                Map.of("manualReview", true, "retryable", false)
        );
        AgentToolRuntimeResult manualReview = new AgentToolRuntimeResult(
                AgentToolExecutionStatus.MANUAL_REVIEW, request, uncertain,
                GuardrailAction.ALLOW, "tool outcome requires manual review", "", false
        );
        when(fixture.runStore.find("run-review")).thenAnswer(invocation -> Optional.of(fixture.persisted.get()));
        when(fixture.runStore.claimForResume("run-review")).thenAnswer(invocation -> {
            AgentRunRecord claimed = fixture.persisted.get().claimedForResume();
            fixture.persisted.set(claimed);
            return Optional.of(claimed);
        });
        when(fixture.runStore.update(anyString(), any())).thenAnswer(invocation -> {
            java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
            AgentRunRecord updated = updater.apply(fixture.persisted.get());
            fixture.persisted.set(updated);
            return updated;
        });
        when(fixture.approvalService.find("approval-review")).thenReturn(Optional.of(approval));
        when(fixture.capabilityRegistry.findCapability("ticket_close")).thenReturn(Optional.of(definition));
        when(fixture.toolRuntime.executeApproved(any(), any(), any())).thenReturn(manualReview);

        AgentRuntimeResult result = fixture.runtime().resume("run-review", AgentEventListener.NOOP);

        assertEquals(AgentRunState.MANUAL_REVIEW, result.state());
        assertEquals(1, fixture.persisted.get().toolResults().size());
        ToolCallResult persistedResult = fixture.persisted.get().toolResults().get(0);
        assertEquals(false, persistedResult.success());
        assertEquals("MANUAL_REVIEW", persistedResult.metadata().get("outcome"));
        assertEquals(1, fixture.persisted.get().budgetSnapshot().toolCalls());
        verify(fixture.timelineStore).appendMessages(
                anyString(), anyString(), anyString(),
                org.mockito.ArgumentMatchers.argThat(messages -> messages.size() == 1
                        && messages.get(0).type() == AgentMessageType.TOOL_RESULT
                        && "call-review".equals(messages.get(0).toolCallId()))
        );
    }

    @Test
    void persistedSuccessfulToolResultIsReusedWithoutDuplicateTimelineMessage() {
        Fixture fixture = new Fixture();
        ToolCallResult result = new ToolCallResult(
                "ticket_close", true, "closed", "", Map.of("source", "persisted")
        );
        AgentMessage existingResult = new AgentMessage(
                "message-1", "session-1", "run-1", 2, AgentMessageType.TOOL_RESULT,
                "closed", "call-1", "ticket_close", Map.of(), Map.of("success", true), 2, Instant.now()
        );
        when(fixture.timelineStore.loadMessages("session-1", 10_000)).thenReturn(List.of(existingResult));

        AgentRuntimeResult recovered = fixture.recoverCertainToolExecution(ToolExecutionState.SUCCEEDED, result);

        assertEquals(AgentRunState.COMPLETED, recovered.state());
        assertEquals(1, fixture.persisted.get().toolResults().size());
        assertEquals(true, fixture.persisted.get().toolResults().get(0).success());
        assertEquals(1, fixture.persisted.get().budgetSnapshot().toolCalls());
        verify(fixture.timelineStore, never()).appendMessages(
                anyString(), anyString(), anyString(),
                org.mockito.ArgumentMatchers.argThat(messages -> messages.stream()
                        .anyMatch(message -> message.type() == AgentMessageType.TOOL_RESULT))
        );
        verify(fixture.toolRuntime, never()).execute(anyString(), anyString(), anyString(), any(), any(), any());
    }

    @Test
    void persistedFailedToolResultIsReturnedToModelForReplanning() {
        Fixture fixture = new Fixture();
        ToolCallResult result = new ToolCallResult(
                "ticket_close", false, "", "remote rejected close", Map.of("source", "persisted")
        );

        AgentRuntimeResult recovered = fixture.recoverCertainToolExecution(ToolExecutionState.FAILED, result);

        assertEquals(AgentRunState.COMPLETED, recovered.state());
        assertEquals(1, fixture.persisted.get().toolResults().size());
        assertEquals(false, fixture.persisted.get().toolResults().get(0).success());
        assertEquals("remote rejected close", fixture.persisted.get().toolResults().get(0).errorMessage());
        assertEquals(1, fixture.persisted.get().budgetSnapshot().toolCalls());
        verify(fixture.modelGateway).nextTurn(any());
        verify(fixture.toolRuntime, never()).execute(anyString(), anyString(), anyString(), any(), any(), any());
    }

    @Test
    void staleGenericToolCanBeReconciledBeforeManualReview() {
        Fixture fixture = new Fixture();
        ToolCallResult reconciled = new ToolCallResult(
                "fixture_recovery_execute", true, "reconciled", "",
                Map.of("recoveredAfterCrash", true, "actionRequestId", "act-1")
        );

        AgentRuntimeResult recovered = fixture.recoverUncertainToolExecution(reconciled);

        assertEquals(AgentRunState.COMPLETED, recovered.state());
        assertEquals(true, fixture.persisted.get().toolResults().get(0).success());
        verify(fixture.toolRuntime).reconcileUncertain(any(ToolExecutionRecord.class));
        verify(fixture.toolRuntime, never()).execute(anyString(), anyString(), anyString(), any(), any(), any());
    }

    private static final class Fixture {
        private final AgentProperties properties = new AgentProperties();
        private final AtomicReference<AgentRunRecord> persisted = new AtomicReference<>();
        private final AgentTimelineStore timelineStore = mock(AgentTimelineStore.class);
        private final AgentRunStore runStore = mock(AgentRunStore.class);
        private final ToolExecutionStore toolExecutionStore = mock(ToolExecutionStore.class);
        private final AgentContextManager contextManager = mock(AgentContextManager.class);
        private final AgentModelGateway modelGateway = mock(AgentModelGateway.class);
        private final AgentCapabilityRegistry capabilityRegistry = mock(AgentCapabilityRegistry.class);
        private final AgentToolRuntime toolRuntime = mock(AgentToolRuntime.class);
        private final GuardrailService guardrailService = mock(GuardrailService.class);
        private final ApprovalService approvalService = mock(ApprovalService.class);
        private final AgentRunControlStore runControlStore = mock(AgentRunControlStore.class);
        private final MemoryService memoryService = mock(MemoryService.class);

        private Fixture() {
            when(capabilityRegistry.listCapabilities()).thenReturn(List.of());
            when(guardrailService.checkInput(anyString()))
                    .thenReturn(GuardrailDecision.allow(GuardrailStage.INPUT, "ok"));
            when(guardrailService.checkOutput(anyString()))
                    .thenReturn(GuardrailDecision.allow(GuardrailStage.OUTPUT, "ok"));
            when(guardrailService.previewOutput(anyString()))
                    .thenReturn(GuardrailDecision.allow(GuardrailStage.OUTPUT, "ok"));
            when(modelGateway.nextTurn(any(), any()))
                    .thenAnswer(invocation -> modelGateway.nextTurn(invocation.getArgument(0)));
            when(runControlStore.renewSessionLease(anyString(), anyString(), any())).thenReturn(true);
            when(runControlStore.cancellationRequested(anyString())).thenReturn(false);
            when(timelineStore.loadEvents(anyString(), anyInt())).thenReturn(List.of());
            when(timelineStore.appendEvent(anyString(), anyString(), anyString(), any()))
                    .thenAnswer(invocation -> new AgentEvent(
                            "event", invocation.getArgument(2), invocation.getArgument(0), 1,
                            ((AgentEventDraft) invocation.getArgument(3)).type(), "event", Map.of(), Instant.now()
                    ));
        }

        private DefaultAgentRuntime runtime() {
            return new DefaultAgentRuntime(
                    properties, timelineStore, runStore, toolExecutionStore, contextManager, modelGateway,
                    capabilityRegistry, toolRuntime, guardrailService, List.of(), approvalService,
                    new ConservativeTokenEstimator(), runControlStore, memoryService,
                    new ConfiguredLlmCostCalculator(properties), new ToolResultProjector(properties)
            );
        }

        private AgentRuntimeResult recoverCertainToolExecution(ToolExecutionState state, ToolCallResult result) {
            AgentRunLimits limits = AgentRunLimits.from(properties);
            AgentExecutionProfile profile = new AgentExecutionProfile(
                    "restricted", "prompt", Set.of("ticket_close"), limits, false
            );
            AgentRunBudget budget = new AgentRunBudget(limits);
            ToolCallRequest pending = new ToolCallRequest("ticket_close", "call-1", Map.of("id", "T1"));
            persisted.set(
                    AgentRunRecord.create(
                                    "run-1", "run-1", "session-1",
                                    new AgentRequest("session-1", "user-1", "close ticket", Map.of()),
                                    profile, budget.snapshot())
                            .checkpoint(AgentRunPhase.EXECUTING_TOOL, pending, List.of(), List.of(), false,
                                    budget.snapshot())
            );
            when(runStore.find("run-1")).thenAnswer(invocation -> Optional.ofNullable(persisted.get()));
            when(runStore.update(anyString(), any())).thenAnswer(invocation -> {
                java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
                AgentRunRecord updated = updater.apply(persisted.get());
                persisted.set(updated);
                return updated;
            });
            Instant now = Instant.now();
            when(toolExecutionStore.findToolExecution("call-1")).thenReturn(Optional.of(
                    new ToolExecutionRecord(
                            "call-1", "run-1", "ticket_close", state, pending, result,
                            1, result.errorMessage(), now, now
                    )
            ));
            when(contextManager.project(anyString(), anyString(), anyString(), anyString(), anyLong(), any(AgentExecutionProfile.class)))
                    .thenReturn(new AgentContextView(List.of(), 0, 0, false));
            when(modelGateway.nextTurn(any())).thenReturn(new AgentModelTurn(
                    "replanned answer", List.of(), "replanned answer",
                    new LlmUsage(10, 5, 15, 0, 0, "test-model", "test"), "stop"
            ));
            return runtime().resume("run-1", AgentEventListener.NOOP);
        }

        private AgentRuntimeResult recoverUncertainToolExecution(ToolCallResult resolvedResult) {
            AgentRunLimits limits = AgentRunLimits.from(properties);
            AgentExecutionProfile profile = new AgentExecutionProfile(
                    "ordercare", "prompt", Set.of("fixture_recovery_execute"), limits, false
            );
            AgentRunBudget budget = new AgentRunBudget(limits);
            ToolCallRequest pending = new ToolCallRequest(
                    "fixture_recovery_execute", "tool-exec-1", Map.of("proposalId", "prop-1")
            );
            persisted.set(AgentRunRecord.create(
                            "run-1", "run-1", "session-1",
                            new AgentRequest("session-1", "user-1", "recover order", Map.of()),
                            profile, budget.snapshot())
                    .checkpoint(AgentRunPhase.EXECUTING_TOOL, pending, List.of(), List.of(), false,
                            budget.snapshot()));
            when(runStore.find("run-1")).thenAnswer(invocation -> Optional.ofNullable(persisted.get()));
            when(runStore.update(anyString(), any())).thenAnswer(invocation -> {
                java.util.function.UnaryOperator<AgentRunRecord> updater = invocation.getArgument(1);
                AgentRunRecord updated = updater.apply(persisted.get());
                persisted.set(updated);
                return updated;
            });
            ToolExecutionRecord running = ToolExecutionRecord.running("run-1", pending);
            ToolExecutionRecord succeeded = running.withResult(ToolExecutionState.SUCCEEDED, resolvedResult, "");
            when(toolExecutionStore.findToolExecution("tool-exec-1")).thenReturn(Optional.of(running));
            when(toolRuntime.reconcileUncertain(running)).thenReturn(succeeded);
            when(contextManager.project(anyString(), anyString(), anyString(), anyString(), anyLong(), any(AgentExecutionProfile.class)))
                    .thenReturn(new AgentContextView(List.of(), 0, 0, false));
            when(modelGateway.nextTurn(any())).thenReturn(new AgentModelTurn(
                    "recovered answer", List.of(), "recovered answer",
                    new LlmUsage(10, 5, 15, 0, 0, "test-model", "test"), "stop"
            ));
            return runtime().resume("run-1", AgentEventListener.NOOP);
        }
    }
}
